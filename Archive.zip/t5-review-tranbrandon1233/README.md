# t5-review
<div class="custom-markdown steps-contents">
    <h2>Summary</h2>
    <p>Marjorie meets with you to discuss the redesign of the blog page showing parenting tips. As with the other pages you&rsquo;ve worked on, she wants this page to be compatible with mobile devices, tablet and desktop devices, and printers. Marjorie has already written the page content and has done much of the initial design work. She needs you to complete the project by writing media queries for the different display options. <em>Figure 5&ndash;61</em> shows a preview of the mobile design and the desktop design.</p>
    <p>
        <img src="https://cdn.filestackcontent.com/VKg7EzVuSFu7HG16clcD" alt="" />&nbsp;&nbsp;
    </p>
    <p><sup><em>Figure 5-61</em></sup></p>
    <p>&nbsp;</p>
    <p>You&rsquo;ll use several flexboxes to create the layout for these two designs so that the page content automatically rescales as the screen width changes.</p>
    <h2>Document Setup</h2>
    <p>Open the <em>tf_tips.html</em>, <em>tf_styles4.css</em>, and <em>tf_print2.css</em> files and enter your <strong>name</strong> and the <strong>date</strong> in the comment section of each file. Next, go to the <em>tf_tips.html</em> file and add a <code>viewport</code> <code>meta</code>tag to the document <code>head</code> to set the <code>width</code> of the layout viewport equal to the <code>width</code> of the device and set the initial scale of the viewport to <strong>1.0</strong>.</p>
    <p>Create links to the following style sheets:</p>
    <ol>
        <li>The <em>tf_base.css</em> file to be used with all devices.</li>
        <li>The <em>tf_styles4.css</em> file to be used with screen devices.</li>
        <li>The <em>tf_print2.css</em> file to be used for printed output.</li>
    </ol>
    <p>Open the <em>tf_styles4.css</em> file. Note that Marjorie has placed all of her styles in the <em>tf_designs.css</em> file and imported them into this style sheet. You will not need to edit that style sheet file, but you might want to view it to become familiar with her style rules.</p>
    <h2>General Flex Styles</h2>
    <p>Go to the "General Flex Styles" section. Within this section, you&rsquo;ll create a flexible layout that varies in response to changing screen widths.</p>
    <p>In the "General Flex Styles" section create a style rule for the <code>body</code> element that:</p>
    <ul>
        <li>displays the page <code>body</code> as a <code>flexbox</code> flowing in the row direction, and</li>
        <li>wraps content to a new line as needed.</li>
    </ul>
    <p>The page content is divided into two section elements with IDs of <code>left</code> and <code>right</code>. The <code>left</code> section does not need as much of the screen width. Create a style rule for the <code>left</code>section that:</p>
    <ul>
        <li>sets its flex growth and shrink rates to <strong>1</strong> and <strong>8</strong> respectively, and</li>
        <li>sets its flex basis size to <strong>130</strong> pixels.</li>
    </ul>
    <p>The <code>right</code> section requires more screen width. Create a style rule for the <code>right</code> section that:</p>
    <ul>
        <li>sets its flex growth and shrink values to <strong>8</strong> and <strong>1</strong>, and</li>
        <li>sets its flex basis size to <strong>351</strong> pixels.</li>
    </ul>
    <p>Next, set the <code>display</code> of the <code>section</code> element with class ID of <code>tips</code> as a <code>flexbox</code>. Have the content of the flexbox flow in the row direction with row wrapping enabled.</p>
    <p>Create a style rule for the <code>article</code> element that:</p>
    <ul>
        <li>lays it out with a flex growth value of <strong>2</strong>,</li>
        <li>sets the flex shrink value of <strong>1</strong>, and</li>
        <li>sets a flex basis size of <strong>351</strong> pixels.</li>
    </ul>
    <p>The biographical asides within each tips section need to occupy less screen space. Create a style rule for the <code>aside</code>element that:</p>
    <ul>
        <li>lays it out with a flex growth value of <strong>1</strong>,</li>
        <li>sets the flex shrink value of <strong>2</strong>, and</li>
        <li>sets a flex basis size of <strong>250</strong> pixels.</li>
    </ul>
    <p>Finally, the horizontal navigation list at the top of the page will also be treated as a <code>flexbox</code>. Create a style rule for the <code>nav.horizontal ul</code> selector that displays it as a <code>flexbox</code>in column orientation with wrapping.</p>
    <h2>Mobile Devices</h2>
    <p>Go to the "Mobile Devices" section and create a media query for screen devices with a maximum width of <strong>480</strong> pixels.</p>
    <p>For mobile devices, the vertical list of links to archived parenting tips should be displayed in several columns at the bottom of the page. Within the media query you created in the last step, add the following style rules:</p>
    <ol>
        <li>For the <code>nav.vertical ul</code> selector, create a style rule that displays it as a <code>flexbox</code> in column orientation with wrapping. Set the <code>height</code> of the element to <strong>240</strong> pixels.</li>
        <li>To give the <code>section</code> element with an ID of <code>left</code> a flex order value of <strong>99</strong> to place it near the bottom of the page.</li>
        <li>To give the <code>body &gt; footer</code> selector an order value of <strong>100</strong> to put it at the page bottom.</li>
    </ol>
    <p>Marjorie wants to hide the navigation list at the top of the page when viewed on a mobile device unless the user hovers (or taps) a navicon. Using the technique shown in this tutorial, add the following style rules to set the behavior of the navicon within the media query for mobile devices:</p>
    <ol>
        <li>Display the navicon by creating a style rule for the <code>a#navicon</code> selector to display it as a block.</li>
        <li>Set the display property of the <code>nav.horizontal ul</code> selector to <strong>none</strong>.</li>
        <li>Display the navigation list contents in response to a hover or touch by creating a style rule for the <code>a#navicon:hover+ul</code>, <code>nav.horizontal ul:hover</code> selector that sets its display value to <strong>block</strong>.</li>
    </ol>
    <h2>Tablets and Desktop Devices</h2>
    <p>Go to the "Tablets and Desktop Devices" section. Create a media query for screen devices with a <code>width</code> of at least <strong>481</strong>pixels. Under the wider screens, the contents of the horizontal navigation list at the top of the page should be displayed in several columns. In order to have the list items wrap to a new column, add a style rule to the media query that sets the height of the <code>ul</code> element within the horizontal navigation list to <strong>160</strong> pixels.</p>
    <p>Verify that as you change the screen width the layout of the page automatically changes to match the layout designs shown in <em>Figure 5&ndash;61</em>. Next, you&rsquo;ll create the print styles for the Parenting Tips page. <em>Figure 5&ndash;62</em> shows a preview of the output on a black and white printer.</p>
    <p>&nbsp;</p>
    <figure>
        <a class="markdown-image-link" title="Open image in a new tab" href="https://cdn.filestackcontent.com/CxCTa0HpT2WPuxKfGxBq" target="_blank" rel="noopener">
            <img src="https://cdn.filestackcontent.com/CxCTa0HpT2WPuxKfGxBq" alt="An image shows page 1 and page 2 of trusted friends daycare webpage in black and white color." />
        </a>
    </figure>
    <p><sup><em>Figure 5-62</em></sup></p>
