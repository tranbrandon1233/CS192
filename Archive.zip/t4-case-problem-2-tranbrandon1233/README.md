# t4-case-problem-2
<h2>Summary</h2>
<p><strong>Chupacabra Music Festival</strong> - Debra Kelly is the director of the website for the Chupacabra Music Festival, which takes place every summer in San Antonio, Texas. Work is already underway on the website design for the 15th annual festival and Debra has approached you to work on the design of the home page. Debra envisions a page that uses semi-transparent colors and 3D transformations to make an attractive and eye-catching page. A preview of her completed design proposal is shown in <em>Figure 4&ndash;71</em>.</p>
<p>&nbsp;</p>
<figure>
    <a class="markdown-image-link" title="Open image in a new tab" href="https://cdn.filestackcontent.com/HG5r0rh8QFWHwOeotRuj" target="_blank" rel="noopener">
        <img src="https://cdn.filestackcontent.com/HG5r0rh8QFWHwOeotRuj" alt="A home page preview of Chupacabra 15 website." />
    </a>
</figure>
<p><sup><em>Figure 4-71</em></sup></p>
<p>&nbsp;</p>
<p>Debra has provided you with the HTML code and the layout and reset style sheets. Your job will be to finish her work by inserting the graphic design styles.</p>
<h2>Document Setup</h2>
<p>Open the <em>cf_home.html</em> and <em>cf_effects.css</em>files and enter your <strong>name</strong> and the <strong>date</strong> in the comment section of each file. Next, go to the <em>cf_home.html</em> file and within the document <code>head</code>, create a link to the <em>cf_reset.css</em>, <em>cf_layout.css</em>, and <em>cf_effects.css</em> style sheets. Take some time to study the content and structure of the document. Pay special note to the nested <code>div</code> elements in the center section of the page; you will use these to create a 3D cube design.</p>
<h2>HTML Styles</h2>
<p>Return to the <em>cf_effects.css</em> file in your editor and go to the "HTML Styles" section. Debra wants a background displaying a scene from last year&rsquo;s festival. Add a style rule for the <code>html</code> element that displays the <em>cf_back1.png</em> as a fixed background, centered horizontally and vertically in the browser window and covering the entire window.</p>
<h2>Body Styles</h2>
<p>Go to the "Body Styles" section and set the background color of the page <code>body</code> to <strong>rgba(255, 255, 255, 0.3)</strong>.</p>
<h2>Body Header Styles</h2>
<p>Go to the "Body Header Styles" section and change the background color of the <code>body header</code> to <strong>rgba(51, 51, 51, 0.5)</strong>.</p>
<h2>Aside Styles</h2>
<p>Debra has placed useful information for the festival in <code>aside</code> elements placed within the left and right <code>section</code>elements. Go to the "Aside Styles" section and create a style rule for the <code>section aside</code> selector that adds a <strong>10</strong>pixel double border with color <strong>rgba(92, 42, 8, 0.3)</strong> and a border radius of <strong>30</strong>pixels.</p>
<p>Debra wants a curved border for every <code>h1</code> heading within an <code>aside</code> element. For the selector <code>section aside h1</code>, create a style rule that sets the border radius of the top-left and top-right corners to <strong>30</strong>pixels.</p>
<p>Define the perspective of the 3D space for the left and right sections by creating a style rule for those two sections that sets their perspective value to <strong>450</strong> pixels. Create a style rule that rotates the <code>aside</code>elements within the left section <strong>25&deg;</strong>around the y-axis. Create another style rule that rotates the <code>aside</code> elements within the right section <strong>&ndash;25&deg;</strong> around the y-axis.</p>
<h2>Cube Styles</h2>
<p>Go to the "Cube Styles" section. Here you&rsquo;ll create the receding cube effect that appears in the center of the page. The cube has been constructed by creating a <code>div</code> element with the id <code>cube</code> containing five <code>div</code> elements belonging to the <code>cube_face</code> class with the ids <code>cube_bottom</code>, <code>cube_top</code>, <code>cube_left</code>, <code>cube_right</code>, and <code>cube_front</code>. (There will be no back face for this cube.) Currently the five faces are superimposed upon each other. To create the cube you have to shift and rotate each face in 3D space so that they form the five faces of the cube. First, position the cube on the page by creating a style rule for the <code>div#cube</code>selector containing the following styles:</p>
<ol>
    <li>Place the element using relative positioning.</li>
    <li>Set the top margin to <strong>180</strong> pixels, the bottom margin to <strong>150</strong> pixels, and the left/right margins to <strong>auto</strong>.</li>
    <li>Set the <code>width</code> and <code>height</code> to <strong>400</strong>pixels.</li>
    <li>Set the perspective of the space to <strong>450</strong>pixels.</li>
</ol>
<p>For each <code>div</code> element of the <code>cube_face</code>class, create a style rule that places the faces with absolute positioning and sets their <code>width</code> and <code>height</code> to <strong>400</strong> pixels.</p>
<p>Finally, you&rsquo;ll construct the cube by positioning each of the five faces in 3D space so that they form the shape of a cube. Add the following style rules for each of the five faces to transform their appearance.</p>
<ol>
    <li>Translate the <code>cube_front div</code>element <strong>&ndash;50</strong> pixels along the z-axis.</li>
    <li>Translate the <code>cube_left div</code> element <strong>&ndash;200</strong> pixels along the x-axis and rotate it <strong>90&deg;</strong> around the y-axis.</li>
    <li>Translate the <code>cube_right div</code>element <strong>200</strong> pixels along the x-axis and rotate it <strong>90&deg;</strong> counter-clockwise around the y-axis.</li>
    <li>Translate the <code>cube_top div</code> element <strong>&ndash;200</strong> pixels along the y-axis and rotate it <strong>90&deg;</strong> counter-clockwise around the x-axis.</li>
    <li>Translate the <code>cube_bottom div</code>element <strong>200</strong> pixels along the y-axis and rotate it <strong>90&deg;</strong> around the x-axis.</li>
</ol>
<p>&nbsp;</p>
