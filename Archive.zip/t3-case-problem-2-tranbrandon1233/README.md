# t3-case-problem-2
<h2>Summary</h2>
<p><strong>A Soldier&rsquo;s Scrapbook</strong> - Jakob Bauer is a curator at the Veteran&rsquo;s Museum in Raleigh, North Carolina. Currently he is working on an exhibit called A Soldier&rsquo;s Scrapbook containing mementos, artifacts, journals, and other historic items from the Second World War. You&rsquo;ve been asked to work on a page for an interactive kiosk used by visitors to the exhibit. Jakob has already supplied much of the text and graphics for the kiosk pages but he wants you to complete the job by working on the page layout. The page you will work on provides an overview of the Normandy beach landings on June 6th, 1944. Since this page will be displayed only on the kiosk monitor, whose screen dimensions are known, you&rsquo;ll employ a fixed layout based on a screen width of 1152 pixels. Jakob also wants you to include an interactive map of the Normandy coast where the user can hover a mouse pointer over location markers to view information associated with each map point. To create this effect, you&rsquo;ll mark each map point as a hypertext link so that you can apply the hover pseudo-class to the location. In addition to the interactive map, Jakob wants you to create a drop cap for the first letter of the first paragraph in the article describing the Normandy invasion. <em>Figure 3&ndash;85</em> shows a preview of the page you&rsquo;ll create.</p>
<p>&nbsp;</p>
<figure>
    <a class="markdown-image-link" title="Open image in a new tab" href="https://cdn.filestackcontent.com/mO3FqTiQvOMjVR6ZjKzR" target="_blank" rel="noopener">
        <img src="https://cdn.filestackcontent.com/mO3FqTiQvOMjVR6ZjKzR" alt="A webpage of Normandy Invasion Kiosk.  The page header displays the heading &ldquo;A soldier&rsquo;s scrapbook&rdquo; with a photo behind.  Six navigation links Blitzkrieg, Battle of Britain, Normandy Invasion, Market Garden, Fall of Berlin, and Postwar Upheaval are given below the page header. A pane at the left displays a section with the heading, The Normandy Invasion with three descriptive paragraphs below it. A pane at the right displays an interactive map in which the pointer is hovered above the map marker. Two paragraphs below the map display the information about the location." />
    </a>
</figure>
<p><sup><em>Figure 3-85</em></sup></p>
<h2>Document Setup</h2>
<p>Open the <em>ss_dday.html</em> and <em>ss_layout.css</em>files and enter your <strong>name</strong> and the <strong>date</strong> in the comment section of each file. Next, go to the <em>ss_dday.html</em> file and within the document <code>head</code>, create links to the <em>ss_styles.css</em> and <em>ss_layout.css</em> style sheet files. Study the content and structure of the document. Note that within the <code>aside</code> element is an image for the battle map with the id <code>mapImage</code>. Also note that there are six marker images enclosed within hypertext links with IDs ranging from <code>marker1</code> to <code>marker6</code>. After each marker image are <code>div</code> elements of the <code>mapInfo</code> class with IDs ranging from <code>info1</code> to <code>info6</code>. Part of your style sheet will include style rules to display these <code>div</code> elements in response to the mouse pointer hovering over each of the six marker images.</p>
<h2>Article Styles</h2>
<p>Open the <em>ss_layout.css</em> file and go to the "Article Styles" section. Within this section, you&rsquo;ll lay out the article describing the Normandy Invasion. Create a style rule to float the <code>article</code> element on the left margin and set its <code>width</code> to <strong>384</strong> pixels.</p>
<h2>First Line and Drop Cap Styles</h2>
<p>Jakob wants the first line from the article to be displayed in small capital letters. Go to the "First Line and Drop Cap Styles" section and create a style rule for the first paragraph of the <code>article</code> element and the first line of that paragraph, setting the font size to <strong>1.25em</strong> and the font variant to small-caps.</p>
<blockquote class="info">
    <p>Use the <code>first-of-type</code> pseudo-class for the paragraph and the <code>first-line</code>pseudo-element for the first line of that paragraph.</p>
</blockquote>
<p>Jakob also wants the first letter of the first line in the article&rsquo;s opening paragraph to be displayed as a drop cap. Create a style rule for the article&rsquo;s first paragraph and first letter that applies the following styles:</p>
<ol>
    <li>Sets the size of the first letter to <strong>4em</strong>in a <strong>serif</strong> font and floats it on the left,</li>
    <li>Sets the line height to <strong>0.8em</strong>, and</li>
    <li>Sets the right and bottom margins to <strong>5</strong>pixels.</li>
</ol>
<blockquote class="info">
    <p>Use the <code>first-letter</code> pseudo-element for the first letter of that paragraph.</p>
</blockquote>
<h2>Aside Styles</h2>
<p>The interactive map is placed within an <code>aside</code> element that Jakob wants displayed alongside the Normandy Invasion article. Go the "Aside Styles" section and create a style rule that sets the <code>width</code> of the <code>aside</code> element to <strong>768</strong>pixels and floats it on the left margin.</p>
<h2>Map Styles</h2>
<p>Next, you will lay out the interactive map. The interactive map is placed within a <code>div</code> element with the ID <code>battleMap</code>. Go to the "Map Styles" section and create a style rule for this element that sets its <code>width</code> to <strong>688</strong> pixels. Center the map by setting its top/bottom margins to <strong>20</strong> pixels and its left/right margins to <strong>auto</strong>. Place the map using relative positioning. The actual map image is placed within an <code>img</code>element with the ID <code>mapImage</code>. Create a style rule for this element that displays it as a block with a <code>width</code> of <strong>100%</strong>.</p>
<h2>Interactive Map Styles</h2>
<p>Go to the "Interactive Map Styles" section. Within this section, you&rsquo;ll create style rules that position each of the six map markers onto the battle map. The markers are placed within hypertext links. Create a style rule for every a element of the <code>battleMarkers</code> class that places the hypertext link using absolute positioning. Create style rules for the six a elements with IDs ranging from <code>marker1</code> to <code>marker6</code>, placing them at the following (top, left) coordinates:</p>
<ol>
    <li><code>marker1</code> <strong>(220, 340)</strong>,</li>
    <li><code>marker2</code> <strong>(194, 358)</strong>,</li>
    <li><code>marker3</code> <strong>(202, 400)</strong>,</li>
    <li><code>marker4</code> <strong>(217, 452)</strong>,</li>
    <li><code>marker5</code> <strong>(229, 498)</strong>,</li>
    <li><code>marker6</code> <strong>(246, 544)</strong>.</li>
</ol>
<h2>Map Information Styles</h2>
<p>The information associated with each map marker has been placed in <code>div</code> elements belonging to the <code>mapInfo</code> class. Go to the "Map Information Styles" section and create a style rule that hides this class of elements so that this information is not initially visible on the page.</p>
<p>To display the information associated with each map maker, you need to create a style rule that changes the map information&rsquo;s display property in response to the mouse pointer hovering over the corresponding map marker. Since the map information follows the map marker in the HTML file, use the following selector to select the map information corresponding to the hovered map marker: <code>a.battleMarkers:hover + div.mapInfo</code>. Write a style rule for this selector that sets its display property to block.</p>
<p>Test the interactive map by first verifying that none of the information about the six battle locations appears on the page unless you hover your mouse pointer over the marker on the battle map. Further verify that when you are not hovering over the battle marker, the information is once again not visible on the page.</p>
