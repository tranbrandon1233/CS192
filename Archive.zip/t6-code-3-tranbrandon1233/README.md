# t6-code-3
<div class="custom-markdown steps-contents">
    <div class="step-block-outer step-block--not-last">
        <div class="step-block-header" role="heading" aria-level="2">
            <div class="custom-markdown steps-contents">
                <div class="custom-markdown steps-contents">
                    <div class="custom-markdown steps-contents">
                        <h2>Summary</h2>
                        <p>You&rsquo;ve been handed a web page that will display the opening chapter of the Charles Dickens novel, Great Expectations. You will lay out the text of the chapter in three columns as shown in <em>Figure 6&ndash;50</em>, with a divided line separating the columns. Write the code for the style sheet.</p>
                        <p>&nbsp;</p>
                        <figure>
                            <a class="markdown-image-link" title="Open image in a new tab" href="https://cdn.filestackcontent.com/2ghuupByRGqE8fotyTCJ" target="_blank" rel="noopener">
                                <img src="https://cdn.filestackcontent.com/2ghuupByRGqE8fotyTCJ" alt="A webpage displays the opening chapter of the novel, Great Expectations. The content of paragraph is displayed in three columns with a divided line separating the columns. An image of a man and small boy is shows at the right of the third column description." />
                            </a>
                        </figure>
                        <sup><em>Figure 6-50</em></sup>
                        <p>&nbsp;</p>
                        <p>Do the following:</p>
                    </div>
                    <div class="step-block-outer step-block--not-last">
                        <div class="step-block-header" role="heading" aria-level="2">Tasks</div>
                        <div class="step-block-header" role="heading" aria-level="2">
                            <br />
                            <span>Open the files </span><em>code6-3.html</em>
                            <span> and </span><em>code6-3_columns.css</em>
                            <span> and in the comment section enter your </span><strong>name</strong>
                            <span> (First + Last) and the </span><strong>date&nbsp;</strong>
                            <span>(MM/DD/YYYY) into the </span><code>Author:</code>
                            <span>and </span><code>Date:</code>
                            <span> fields of each file.</span>
                        </div>
                        <div class="step-block-header" role="heading" aria-level="2">
                            <br />
                            <span>Go to the </span><em>code6-3.html</em>
                            <span> file and within the </span><code>head</code>
                            <span> section insert </span><code>link</code>
                            <span> elements linking the page to the </span><em>code6-3_layout.css</em>
                            <span> and </span><em>code6-3_columns.css</em>
                            <span> files.</span>
                        </div>
                        <div class="step-block-header" role="heading" aria-level="2">
                            <br />
                            <span>Open the </span><em>code6-3_columns.css</em>
                            <span>file and create a style rule for the </span><code>article</code>
                            <span> element to display the contents in a </span><strong>3</strong>
                            <span> column layout with a minimum column </span><code>width</code>
                            <span> of </span><strong>350&nbsp;</strong>
                            <span>pixels, separate the columns with a </span><strong>5</strong>
                            <span> pixel border in the ridge style and using the color value </span><strong>rgb(231, 231, 231)</strong>
                            <span>, and set the space between the columns to </span><strong>20</strong>
                            <span> pixels.</span>
                        </div>
                        <div class="step-block-header" role="heading" aria-level="2">
                            <br />
                            <span>Create a style rule for the </span><code>h1</code>
                            <span>element within the </span><code>article</code>
                            <span>element to span the heading across all columns, center the heading text, and set the font size to </span><strong>3.5em</strong>
                            <span> with a letter spacing of </span><strong>0.15em</strong>
                            <span>.</span>
                        </div>
                        <div class="step-block-header" role="heading" aria-level="2">
                            <br />
                            <span>Create a style rule for paragraphs within the </span><code>article</code>
                            <span>element to set the minimum size of widows and orphans to </span><strong>4</strong>
                            <span> lines.</span>
                        </div>
                        <div class="step-block-header" role="heading" aria-level="2">
                            <br />
                            <span>View the page in your browser to verify the contents match that shown in </span><em>Figure 6&ndash;50</em>
                            <span>.</span>
                        </div>
                    </div>
                </div>
            </div>
