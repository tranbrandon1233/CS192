<h1>T3 Coding Challenge 2</h1>
<div class="custom-markdown steps-contents">
    <div class="custom-markdown steps-contents">
        <h2>Summary</h2>
        <p><em>Figure 3&ndash;80</em>
            <span>&nbsp;</span>shows a proposed layout for a new web page. At this point the final content is not ready for the web page, so the layout is shown using lorem ipsum text. You&rsquo;ve been given the HTML code for the page and your challenge is to create the page layout using CSS grid styles.
        </p>
        <p>&nbsp;</p>
        <figure>
            <a class="markdown-image-link" title="Open image in a new tab" href="https://cdn.filestackcontent.com/lnq5g1OqSLysDUVzWpA5" target="_blank" rel="noopener">
                <img src="https://cdn.filestackcontent.com/lnq5g1OqSLysDUVzWpA5" alt="A layout of a webpage with grid items outlined. The page header is at the top and six grids for navigation links are given below the header. Below the navigation links, the content of information is given in three columns in which the third column further divided into two grids as side 1 and side 2. The footer is displayed at the bottom of each column. " />
            </a>
        </figure>
        <sup><em>Figure 3-80</em></sup>
        <p>&nbsp;</p>
        <p>Do the following:</p>
    </div>
    <div class="step-block-outer step-block--not-last">
        <div class="step-block-header" role="heading" aria-level="2"><strong>Tasks</strong></div>
        <div class="step-block-header" role="heading" aria-level="2">
            <span>Open the file&nbsp;</span><em>code3-2.html</em>
            <span>&nbsp;and&nbsp;</span><em>code3-2_layout.css</em>
            <span>&nbsp;and in the comment section enter your&nbsp;</span><strong>name</strong>
            <span>&nbsp;(First + Last) and the&nbsp;</span><strong>date</strong>
            <span>&nbsp;(MM/DD/YYYY) into the&nbsp;</span><code>Author:</code>
            <span>&nbsp;and&nbsp;</span><code>Date:</code>
            <span>&nbsp;fields of the file.
                <br />
            </span>
        </div>
        <div class="step-block-header" role="heading" aria-level="2">
            <span>
                <br />Go to the&nbsp;<em>code3-2.html</em>&nbsp;file and within the head section insert a&nbsp;<code>link</code>&nbsp;element linking the page to the&nbsp;<em>code3-2_layout.css</em>&nbsp;file. Study the contents of the file, taking note of the structure, element names, and element ids.
            </span>
        </div>
        <div class="step-block-header" role="heading" aria-level="2">
            <br />
            <span>Go to the&nbsp;</span><em>code3-2_layout.css</em>
            <span>&nbsp;file. Create a style rule for the&nbsp;</span><code>header</code>
            <span>,&nbsp;</span><code>footer</code>
            <span>,&nbsp;</span><code>aside</code>
            <span>,&nbsp;</span><code>article</code>
            <span>, and&nbsp;</span><code>a</code>
            <span>&nbsp;(hyperlink) elements to set the padding space to&nbsp;</span><strong>10</strong>
            <span>&nbsp;pixels and add a&nbsp;</span><strong>3-pixel</strong>
            <span>&nbsp;</span><strong>gray</strong>
            <span>&nbsp;dashed outline.</span>
        </div>
        <div class="step-block-header" role="heading" aria-level="2">
            <br />
            <p>Create a style rule for the<span>&nbsp;</span><code>body</code>
                <span>&nbsp;</span>element that:
            </p>
            <ol>
                <li>Sets the<span>&nbsp;</span><code>width</code>
                    <span>&nbsp;</span>to<span>&nbsp;</span><strong>90%</strong>
                    <span>&nbsp;</span>of the browser window, ranging from a minimum width of<span>&nbsp;</span><strong>640</strong>
                    <span>&nbsp;</span>pixels up to a maximum width of<span>&nbsp;</span><strong>1024</strong>
                    <span>&nbsp;</span>pixels.
                </li>
                <li>Sets the top/bottom margin to<span>&nbsp;</span><strong>30</strong>
                    <span>&nbsp;</span>pixels and the left/right margin to<span>&nbsp;</span><strong>auto</strong>.
                </li>
                <li>Displays the<span>&nbsp;</span><code>body</code>
                    <span>&nbsp;</span>as a CSS grid.
                </li>
                <li>Creates six grid columns each with a<span>&nbsp;</span><code>width</code>
                    <span>&nbsp;</span>of<span>&nbsp;</span><strong>1fr</strong>.
                </li>
                <li>Creates five grid rows with widths of<span>&nbsp;</span><strong>50</strong>
                    <span>&nbsp;</span>pixels,<span>&nbsp;</span><strong>30</strong>
                    <span>&nbsp;</span>pixels,<span>&nbsp;</span><strong>1fr</strong>,<span>&nbsp;</span><strong>1fr</strong>, and<span>&nbsp;</span><strong>100</strong>
                    <span>&nbsp;</span>pixels.
                </li>
                <li>Adds a grid gap of<span>&nbsp;</span><strong>15</strong>
                    <span>&nbsp;</span>pixels
                </li>
            </ol>
            <p>Set the size of the grid items as follows:</p>
            <ol>
                <li>Have the<span>&nbsp;</span><code>header</code>
                    <span>&nbsp;</span>element span from<span>&nbsp;</span><strong>gridline 1</strong>
                    <span>&nbsp;</span>to<span>&nbsp;</span><strong>gridline -1</strong>.
                </li>
                <li>Have the<span>&nbsp;</span><code>article#intro</code>
                    <span>&nbsp;</span>element span two rows and two columns.
                </li>
                <li>Have the<span>&nbsp;</span><code>article#main</code>
                    <span>&nbsp;</span>element two rows and three columns.
                </li>
                <li>Have the<span>&nbsp;</span><code>footer</code>
                    <span>&nbsp;</span>element span two columns.
                </li>
            </ol>
            <p>
                <span>Open the webpage in the browser preview and verify the layout of the page resembles that shown in&nbsp;</span><em>Figure 3&ndash;80</em>
                <span>.</span>
            </p>
        </div>
    </div>
</div>
