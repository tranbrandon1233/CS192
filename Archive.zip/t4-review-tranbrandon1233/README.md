# t4-review
<div class="custom-markdown steps-contents">
    <p>Kevin wants you to work on another family page for the Tree and Book website. The page was created for the Ferris family with content provided by Linda Ferris-White. Kevin is examining a new color scheme and design style for the page. A preview of the design you&rsquo;ll create is shown in <em>Figure 4&ndash;68</em>.</p>
    <p>&nbsp;</p>
    <figure>
        <a class="markdown-image-link" title="Open image in a new tab" href="https://cdn.filestackcontent.com/4p7QCzTDTLSlC62g3ZMc" target="_blank" rel="noopener">
            <img src="https://cdn.filestackcontent.com/4p7QCzTDTLSlC62g3ZMc" alt="A home page preview of Tree and Book website. In the page content, the title &ldquo;The Ferris Family&rdquo; is centered with a photo below. Three paragraphs of content about the Ferris family are described below the photo." />
        </a>
    </figure>
    <sup><em>Figure 4-68</em></sup>
    <p>&nbsp;</p>
    <p>All of the HTML content and the typographical and layout styles have already been created for you. Your task will be to complete the work by writing the visual style sheet to incorporate Kevin&rsquo;s suggestions.</p>
    <h2>Document Setup</h2>
    <p>Open the <em>tb_visual3.css</em>, <em>tb_visual4.css</em>, <em>tb_ferris.html</em> and <em>tb_kathleen.html</em> files and enter your <strong>name</strong> and the <strong>date</strong> in the comment section of each file. Next, go to the <em>tb_ferris.html</em> file and add links to the <em>tb_base.css</em>, <em>tb_styles3.css</em>, and <em>tb_visual3.css</em> style sheets in the order listed.</p>
    <p>Scroll down and, within the <code>main</code> element header and after the <code>h1</code> heading, insert a figure box containing:</p>
    <ol>
        <li>The <em>tb_ferris.png</em> inline image with the alternate text <strong>Ferris Family</strong> using the image map named <code>portrait_map</code>.</li>
        <li>A figure caption with the text <strong>Kathleen Ferris and daughter Linda (1961)</strong>.</li>
    </ol>
    <p>Directly below the figure box, create the <code>portrait_map</code> image map containing the following hotspots:</p>
    <ol>
        <li>A rectangular hotspot pointing to the <em>tb_kathleen.html</em> file with the left-top coordinate <strong>(10, 50)</strong> and the right-bottom coordinate <strong>(192, 223)</strong> and alternate text, <strong>Kathleen Ferris</strong></li>
        <li>A circular hotspot pointing to the <em>tb_linda.html</em> file with a center point at <strong>(264, 108)</strong> and a radius of <strong>80</strong> pixels and the alternate text, <strong>Linda Ferris-White</strong>.</li>
    </ol>
    <h2>HTML Styles</h2>
    <p>Open the <em>tb_visual3.css</em> file in order to create the graphic design styles for the page. Go to the "HTML Styles" section and create a style rule for the <code>html</code> element to use the image file <em>tb_back5.png</em> as the background.</p>
    <h2>Page Body Styles</h2>
    <p>Go to the "Page Body Styles" section and create a style rule for the <code>body</code> element that:</p>
    <ol>
        <li>Adds a left and right <strong>3</strong> pixel solid border with color value <strong>rgb(169, 130, 88)</strong></li>
        <li>Adds a box shadow to the right border with a horizontal offset of <strong>25</strong> pixels, a vertical offset of <strong>0</strong> pixels and a <strong>35</strong> pixel blur and a color value of <strong>rgb(53, 21, 0)</strong>, and then adds the mirror images of this shadow to the left border.</li>
    </ol>
    <h2>Main Styles</h2>
    <p>Go to the "Main Styles" section. Create a style rule for the <code>main</code> element that:</p>
    <ol>
        <li>Applies the <em>tb_back7.png</em> file as a background image with a size of <strong>100%</strong>covering the entire background with no tiling and positioned with respect to the padding box</li>
        <li>Adds two inset box shadows, each with a <strong>25</strong> pixel blur and a color value of <strong>rgb(71, 71, 71)</strong>, and then one with offsets of <strong>&ndash;10</strong> pixels in the horizontal and vertical direction and the other with horizontal and vertical offsets of <strong>10</strong> pixels.</li>
    </ol>
    <p>Create a style rule for the <code>h1</code> heading within the <code>main</code> header that adds the following two text shadows:</p>
    <ol>
        <li>A shadow with the color value <strong>rgb(221, 221, 221)</strong> and offsets of <strong>1</strong> pixels and no blurring</li>
        <li>A shadow with the color value <strong>rgba(41, 41, 41, 0.9)</strong> and offsets of <strong>5</strong>pixels and a <strong>20</strong> pixel blur.</li>
    </ol>
    <h2>Figure Box Styles</h2>
    <p>Go to the "Figure Box Styles" section. Create a style rule for the <code>figure</code>element that sets the top/bottom margin to <strong>10</strong> pixels and the left/right margin to <strong>auto</strong>. Set the <code>width</code> of the element to <strong>70%</strong>.</p>
    <p>Next, you&rsquo;ll modify the appearance of the figure box image. Create a style rule for the image within the figure box that:</p>
    <ol>
        <li>Sets the border width to <strong>25</strong> pixels.</li>
        <li>Sets the border style to <strong>solid</strong>.</li>
        <li>Applies the <em>tb_frame.png</em> file as a border image with a slice size of <strong>60</strong>pixels stretched across the sides.</li>
        <li>Displays the image as a block with a <code>width</code> of <strong>100%</strong>.</li>
        <li>Applies a <strong>sepia</strong> tone to the image with a value of <strong>80%</strong> (include the WebKit browser extension in your style sheet).</li>
    </ol>
    <p>Create a style rule for the figure caption that:</p>
    <ol>
        <li>Displays the text using the font stack <strong>Palatino Linotype</strong>, <strong>Palatino</strong>, <strong>Times New Roman</strong>, <strong>serif</strong>.</li>
        <li>Sets the style to <strong>italic</strong>.</li>
        <li>Sets the top/bottom padding to <strong>10</strong>pixels and the left/right padding to <strong>0</strong>pixels.</li>
        <li>Centers the text.</li>
    </ol>
    <h2>Article Styles</h2>
    <p>Go to the "Article Styles" section. Here you&rsquo;ll create borders and backgrounds for the <code>article</code> that Linda Ferris-White wrote about her mother. Create a style rule for the <code>article</code> element that:</p>
    <ol>
        <li>Displays the background image file <em>tb_back6.png</em> placed at the bottom-right corner of the element with a size of <strong>15%</strong> and no tiling.</li>
        <li>Add an <strong>8</strong> pixel double border with color value <strong>rgb(147, 116, 68)</strong> to the right and bottom sides of the <code>article</code>element.</li>
        <li>Creates a curved bottom-right corner with a radius of <strong>80</strong> pixels.</li>
        <li>Add an interior shadow with horizontal and vertical offsets of <strong>&ndash;10</strong> pixels, a <strong>25</strong>pixel blur, and a color value of <strong>rgba(184, 154, 112, 0.7)</strong>.</li>
    </ol>
    <h2>Footer Styles</h2>
    <p>Kevin wants a gradient background for the page <code>footer</code>. Go to the "Footer Styles" section and create a style rule for the <code>footer</code> that adds a linear gradient background with an angle of <strong>325&deg;</strong>, going from the color value <strong>rgb(180, 148, 104)</strong>with a color stop at <strong>20%</strong> of the gradient length to the value <strong>rgb(40, 33, 23)</strong> with a color stop at <strong>60%</strong>.</p>
    <p>Next, you will create the design styles for individual pages about Kathleen Ferris and Linda Ferris-White. A preview of the content of the Kathleen Ferris page is shown in <em>Figure 4&ndash;69</em>.</p>
    <p>&nbsp;</p>
    <figure>
        <a class="markdown-image-link" title="Open image in a new tab" href="https://cdn.filestackcontent.com/ldrQZfoGTFm7GWlN1tgV" target="_blank" rel="noopener">
            <img src="https://cdn.filestackcontent.com/ldrQZfoGTFm7GWlN1tgV" alt="A webpage of Kathleen Ferris displays three images. The first image is displayed at the top, the second image displayed at the bottom left is rotated to negative 50 degree along the y axis.  The third image displayed at the bottom right is rotated 50 degree along the y axis." />
        </a>
    </figure>
    <p><sup><em>Figure 4-69</em></sup></p>
    <p>&nbsp;</p>
    <p>Go to the <em>tb_kathleen.html</em> file and create links to the <em>tb_base.css</em>, <em>tb_styles4.css</em>, and <em>tb_visual4.css</em> files. Study the contents of the file and then close it.</p>
    <h2>Transformation Styles</h2>
    <p>Go to the <em>tb_visual4.css</em> file and scroll down to the "Transformation Styles" section and add a style rule for the <code>article</code> element to set the size of the perspective space to <strong>800</strong> pixels.</p>
    <p>Create a style rule for the <code>figure1</code> figure box to translate it <strong>&ndash;120</strong> pixels along the z-axis. Create a style rule for the <code>figure2</code>figure box to translate it <strong>&ndash;20</strong> pixels along the y-axis and rotate it <strong>50&deg;</strong> around the y-axis. Create a style rule for the <code>figure3</code>figure box to translate it <strong>&ndash;30</strong> pixels along the y-axis and rotate it <strong>&ndash;50&deg;</strong> around the y-axis.</p>
    <h2>Filter Styles</h2>
    <p>Next, go to the "Filter Styles" section to apply CSS filters to the page elements. Create a style rule for the <code>figure1</code> figure box that applies a saturation filter with a value of <strong>1.3</strong>. Create a style rule for the <code>figure2</code> figure box that sets the brightness to <strong>0.8</strong> and the contrast to <strong>1.5</strong>. Create a style rule for the <code>figure3</code> figure box that sets the hue rotation to <strong>170&deg;</strong>, the saturation to <strong>3</strong>, and the brightness to <strong>1.5</strong>.</p>
    <p>&nbsp;</p>
</div>
