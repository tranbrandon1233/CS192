# t6-review
DLR Morning Schedule
<div class="custom-markdown steps-contents">
    <h2>Summary</h2>
    <p>Kyle has reviewed your work on the DLR nightly schedule page. He wants you to make a few changes to the layout and apply those changes to a new page that describes the DLR morning schedule. Kyle already has entered much of the web page content and style. He wants you to complete his work by creating and designing the web table listing the times and programs for the morning schedule. <em>Figure 6&ndash;52</em> shows a preview of the morning schedule page.</p>
    <p>&nbsp;</p>
    <figure>
        <a class="markdown-image-link" title="Open image in a new tab" href="https://cdn.filestackcontent.com/OxQauoWmS7KEbyBZRPIB" target="_blank" rel="noopener">
            <img src="https://cdn.filestackcontent.com/OxQauoWmS7KEbyBZRPIB" alt="A webpage displays a D L R Morning Schedule. The first column displays the Time, the other columns displays the weekdays. The row element displays the time and names of the different D L R programs from 5:00 a.m. to 12:00 p.m." />
        </a>
    </figure>
    <h2><sup><em>Figure 6&ndash;52</em></sup></h2>
    <p>&nbsp;</p>
    <h2>Document Setup</h2>
    <p>Open the <em>dlr_mornings.html</em>, <em>dlr_tables2.css</em>and <em>dlr_columns2.css</em> files and enter your <strong>name</strong> and the <strong>date</strong> in the comment section of each file. Next, go to the <em>dlr_mornings.html</em> file and insert links to the <em>dlr_tables2.css</em> and <em>dlr_columns2.css</em> style sheets.</p>
    <h2>Create the Web Table</h2>
    <p>Scroll down the file and directly below the paragraph element, insert a web table and do the following:</p>
    <ul>
        <li>Set the class name of the web table to <code>programs</code>.</li>
        <li>Add a table caption containing the text <strong>All Times Central</strong>.</li>
        <li>insert a <code>colgroup</code> element containing three columns below the caption.
            <ul>
                <li>set the first <code>col</code> element should have the class name <code>timeColumn</code>.</li>
                <li>set the second <code>col</code> element should have the class name <code>wDayColumns</code> and span five columns in the table that will contain the weekday programs.</li>
                <li>set the last <code>col</code> element should have the class name <code>wEndColumns</code> and span the last two columns containing the weekend programming.</li>
            </ul>
        </li>
        <li>Add the <code>thead</code> row group element containing a single table row with <code>th</code>elements containing the text shown in <em>Figure 6&ndash;52</em>.</li>
        <li>Add the <code>tbody</code> row group element containing the times and names of the different DLR programs from 5:00 a.m. to 12:00 p.m., Monday through Sunday, in half-hour intervals. The times should be placed in <code>th</code> elements and the program names in <code>td</code> elements.</li>
        <li>Create row and column spanning cells to match the layout of the days and times shown in <em>Figure 6&ndash;52</em>.</li>
        <li>Add the <code>tfoot</code> row group element containing a single row with a single <code>td</code> element that spans 8 columns and contains the text <strong>Support your Public Radio Station</strong>.</li>
    </ul>
    <h2>Table Styles</h2>
    <p>Close the <em>dlr_mornings.html</em> file and open the <em>dlr_tables2.css</em> and go to the "Table Styles" section. Create a style rule for the <code>programs</code> table that:</p>
    <ol>
        <li>Set the <code>width</code> of the table to <strong>100%</strong>.</li>
        <li>Add a <strong>15</strong> pixel outset border with a color value of <strong>rgb(151, 151, 151)</strong>.</li>
        <li>Defines the borders so that they are collapsed around the table.</li>
        <li>Set the font family to the font stack: <strong>Arial</strong>, <strong>Verdana</strong>, and <strong>sans-serif</strong>.</li>
    </ol>
    <p>Create a style rule that sets the <code>height</code> of every table row to <strong>25</strong> pixels and add a style rule for every <code>th</code> and <code>td</code> element that:</p>
    <ol>
        <li>adds a <strong>1</strong> pixel solid gray border,</li>
        <li>aligns the cell content with the top of the cell, and</li>
        <li>sets the padding space <strong>5</strong> pixels.</li>
    </ol>
    <h2>Table Caption Styles</h2>
    <p>Go to the "Table Caption Styles" section and create a style rule that places the <code>caption</code> element at the bottom of the table and centered horizontally.</p>
    <h2>Table Column Styles</h2>
    <p>Go to the "Table Column Styles" section. For <code>col</code> elements belonging to the <code>timeColumn</code> class, create a style rule that sets the column <code>width</code> to <strong>10%</strong> and the background color to the value <strong>rgb(215, 205, 151)</strong>.</p>
    <p>For <code>col</code> elements of the <code>wDayColumns</code>class, create a style rule that sets the column <code>width</code> to <strong>11%</strong> and the background color to <strong>rgb(236, 255, 211)</strong>. For <code>col</code>elements of the <code>wEndColumns</code> class, create a style rule that sets the column <code>width</code> to <strong>17%</strong> and the background color to <strong>rgb(255, 231, 255)</strong>.</p>
    <h2>Table Header Styles</h2>
    <p>Kyle wants you to format the table heading cells from the table header row. Go to the "Table Header Styles" section and create a style rule to set the font color of the text within the <code>thead</code> element to <strong>white</strong> and the background color to a <strong>medium green&nbsp;</strong>with the value <strong>rgb(105, 177, 60)</strong>.</p>
    <p>The different cells in the table header row should be formatted with different text and background colors. Using the <code>first-of-type</code> pseudo-class, create a style rule that changes the background color of the first <code>th</code> element with the <code>thead</code> element to <strong>rgb(153, 86, 7)</strong>.</p>
    <p>Using the <code>nth-of-type</code> pseudo-class, create style rules that change the background color of the <strong>7</strong>th and <strong>8</strong>th <code>th</code> elements within the <code>thead</code> element to <strong>rgb(153, 0, 153)</strong>.</p>
    <h2>Table Footer Styles</h2>
    <p>Kyle wants the table footer to be formatted in a different text and background color from the rest of the table. Go to the "Table Footer Styles" section. Create a style rule for the <code>tfoot</code> element that sets the font color to <strong>white</strong> and the background color to <strong>black</strong>.</p>
    <h2>Column Styles</h2>
    <p>Return to the <em>dlr_columns2.css</em> file. Kyle wants the introductory paragraph to appear in a three column layout for desktop devices. Within the "Column Styles" section, create a media query for screen devices with minimum widths of <strong>641</strong> pixels. Within the media query, create a style rule for the paragraph element that:</p>
    <ol>
        <li>sets the column count to <strong>3</strong>,</li>
        <li>sets the column gap to <strong>20</strong> pixels, and</li>
        <li>adds a <strong>1</strong> pixel <strong>solid black</strong> dividing line between columns.</li>
    </ol>
    <p>Open the <em>dlr_mornings.html</em> file in your browser and verify that the table layout and design resemble that shown in <em>Figure 6&ndash;52</em>.</p>
