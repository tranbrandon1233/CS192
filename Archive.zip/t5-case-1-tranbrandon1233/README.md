# t5-case-1
<h2>Summary</h2>
<p><strong>Golden Pulps</strong> - Devan Ryan manages the website Golden Pulps, where he shares tips on collecting and fun stories from the &ldquo;golden age of comic books&rdquo;&mdash;a period of time covering 1938 through the early 1950s. Devan wants to provide online versions of several classic comic books, which are now in the public domain. He&rsquo;s scanned the images from the golden age comic book, America&rsquo;s Greatest Comics 001, published in March, 1941, by Fawcett Comics and featuring Captain Marvel. He&rsquo;s written the code for the HTML file and wants you to help him develop a layout design that will be compatible with mobile and desktop devices. <em>Figure 5&ndash;63</em> shows a preview of the mobile and desktop version of a page you&rsquo;ll create.</p>
<p>
    <img src="https://cdn.filestackcontent.com/Vqj2VLXSt2eIuKO2ZBLK" alt="Two screenshots display a webpage of Golden Pulps in mobile and desktop versions. In the mobile version, three panel cartoons are arranged one below the other. At the bottom of the page, the description about Captain Marvel and the navigation links are displayed. In the desktop version, the navigation bar is displayed below the page header. In the page, the grid of the three panel cartoons and the description about Captain Marvel are displayed beside each other. " />
</p>
<h2><sup><em>Figure 5-63</em></sup></h2>
<div class="custom-markdown steps-contents">
    <h2>Document Setup</h2>
    <p>Open the <em>gp_cover.html</em>, <em>gp_page1.html</em>, <em>gp_page2.html</em>, <em>gp_page3.html</em>, <em>gp_layout.css</em>, and <em>gp_print.css</em> files and enter your <strong>name</strong> and the <strong>date</strong> in the comment section of each file. Next, go to the <em>gp_cover.html</em> file and add a <code>viewport</code> <code>meta</code> tag to the document <code>head</code>, setting the <code>width</code> of the layout viewport to the device width and setting the initial scale of the viewport to <strong>1.0</strong>.</p>
    <p>Create links to the following style sheets:</p>
    <ol>
        <li>the <em>gp_reset.css</em> file to be used with all devices,</li>
        <li>the <em>gp_layout.css</em> file to be used with screen devices, and</li>
        <li>the <em>gp_print.css</em> file to be used for printed output.</li>
    </ol>
    <p>Take some time to study the contents and structure of the file. Note each panel from the comic book is stored as a separate inline image with the class name panel along with class names of <code>size1</code> to <code>size4</code> indicating the size of the <code>panel</code>. <code>Size1</code> is the largest panel down to <code>size4</code>, which is the smallest panel.</p>
    <p>Repeat the above step, adding the stylesheet links and the viewport information to each of the <em>gp_page1.html</em>, <em>gp_page2.html</em>, and <em>gp_page3.html</em> files. Finally, go to the <em>gp_layout.css</em> file and create the layout styles for mobile and desktop devices. Note that Devan has used the <code>@import</code> rule to import the <em>gp_designs.css</em> file, which contains several graphical and typographical style rules.</p>
    <div class="custom-markdown steps-contents">
        <h2>Flex Layout Styles</h2>
        <p>Go to the "Flex Layout Styles" section and insert a style rule to display the <code>body</code>element as a <code>flexbox</code> oriented as rows with wrapping. The page <code>body</code> content has two <code>main</code> elements. The <code>section</code>element with the ID <code>sheet</code> contains the panels from the comic book page. The <code>article</code> element contains information about the comic book industry during the Golden Age. Devan wants more of the page width to be given to the comic book sheet. Add a style rule that sets the flex growth and shrink rate of the <code>section#sheet</code>selector to <strong>3</strong> and <strong>1</strong> respectively and set its flex basis size to <strong>301</strong> pixels.</p>
        <p>Less page width will be given to the <code>article</code> element. Create a style rule to set its flex growth and shrink values to <strong>1</strong>and <strong>3</strong> respectively and set its flex basis size to <strong>180</strong> pixels.</p>
        <h2>Mobile Devices</h2>
        <p>Go to the "Mobile Devices" section and create a media query for screen devices with a maximum width of <strong>480</strong> pixels.</p>
        <p>With mobile devices, Devan wants each comic book panel image to occupy a single row. Create a style rule that sets the <code>width</code> of <code>img</code> elements belonging to the <code>panel</code> class to <strong>100%</strong>. Devan wants the horizontal navigation links to other pages on the Golden Pulps website to be displayed near the bottom of the page. Within the media query, set the flex order of the <code>nav.horizontal</code> selector to <strong>99</strong>. Create a style rule to set the flex order of the <code>body &gt; footer</code> selector to <strong>100</strong>.</p>
        <div class="custom-markdown steps-contents">
            <h2>Tablet and Desktop Devices</h2>
            <p>Go to the "Tablet and Desktop Devices: Greater than 480 pixels" section and create a media query that matches screen devices with widths greater than <strong>480</strong> pixels. For tablet and desktop devices, you&rsquo;ll lay out the horizontal navigation list as a single row of links. Within the media query, create a style rule for the <code>nav.horizontal ul</code>selector that displays that element as a <code>flexbox</code>, oriented in the row direction with no wrapping. Set the <code>height</code> of the element to <strong>40</strong> pixels.</p>
            <p>For the <code>nav.horizontal ul li</code> selector set the flex growth shrink, and basis size values to <strong>1</strong>, <strong>1</strong>, and <strong>auto</strong> respectively so that each list items grows and shrinks at the same rate.</p>
            <p>With wider screens, Devan does not want the panels to occupy their own rows as is the case with mobile devices. Instead, within the media query create style rules, define the <code>width</code> of the different classes of comic book panel images as follows:</p>
            <ol>
                <li>Set the <code>width</code> of <code>size1</code> <code>img</code>elements to <strong>100%</strong>.</li>
                <li>Set the <code>width</code> of <code>size2</code> <code>img</code>elements to <strong>60%</strong>.</li>
                <li>Set the <code>width</code> of <code>size3</code> <code>img</code>elements to <strong>40%</strong>.</li>
                <li>Set the <code>width</code> of <code>size4</code> <code>img</code>elements to <strong>30%</strong>.</li>
            </ol>
            <p>Open the website in the preview pane to the right and click the navigation links to view the contents of the cover and first three pages. Verify that with a narrow screen the panels occupy their own rows and with a wider screen the sheets are laid out with several panels per row. Further verify that the horizontal navigation list is placed at the bottom of the page for mobile devices.</p>
            <h2>Print Style</h2>
            <p>Devan also wants a print style that displays each comic book sheet on its own page and with none of the navigation links. Go to the <em>gp_print.css</em> style sheet in your editor. Add style rules to:</p>
            <ol>
                <li>In the section marked "Hidden Objects", hide the <code>nav</code>, <code>footer</code>, and <code>article</code> elements.</li>
                <li>In the section marked "Comic Book Sheet Styles", set the <code>width</code> of the element referenced by the <code>section#sheet</code> selector to <strong>6</strong> inches. Set the top/ bottom margin of that element to <strong>0</strong> inches and the left/right margin to <strong>auto</strong> in order to center it within the printed page.</li>
                <li>Set the <code>width</code> of <code>img</code> elements belong to the <code>size1</code> class to <strong>5</strong> inches, <code>size2</code> images to <strong>3</strong> inches, <code>size3</code>images to <strong>2</strong> inches, and <code>size4</code> images to <strong>1.5</strong> inches.</li>
            </ol>
        </div>
    </div>
</div>
