# t3-case-problem-1
<div class="custom-markdown steps-contents">
    <h2>Summary</h2>
    <p><strong>Slate &amp; Pencil Tutoring</strong> - Karen Cooke manages the website for Slate &amp; Pencil Tutoring, an online tutoring service for high school and college students. Karen is overseeing the redesign of the website and has hired you to work on the layout of the site&rsquo;s home page. <em>Figure 3&ndash;84</em> shows a preview of the page you&rsquo;ll create for Karen.</p>
    <p>&nbsp;</p>
    <figure>
        <a class="markdown-image-link" title="Open image in a new tab" href="https://cdn.filestackcontent.com/D010jfNQS82p116MfMyH" target="_blank" rel="noopener">
            <img src="https://cdn.filestackcontent.com/D010jfNQS82p116MfMyH" alt="A webpage of slate and pencil tutoring. The page header displays the heading Slate and Pencil Tutoring with a photo. The left of the header shows 8 navigation links, Home, Our Tutors, Pricing, Testimonials, Your Account, Chat Online, Error Reporting, and Instructor Portal are given. Below the header, 8 links for the subjects, Math, Science, English, Languages, history, Sociology, Art, and Other are given. Below the links, four images with info are displayed. Six reviews of students are displayed below the images." />
        </a>
    </figure>
    <h2><sup><em>Figure 3-84</em></sup></h2>
    <p>&nbsp;</p>
    <p>Karen has supplied you with the HTML file and the graphic files. She has also given you a base style sheet to initiate your web design and a style sheet containing several typographic styles. Your job will be to write up a layout style sheet according to Karen&rsquo;s specifications.</p>
    <h2>Document Setup</h2>
    <p>Open the <em>sp_home.html</em> and <em>sp_layout.css</em>files and enter your <strong>name</strong> and the <strong>date</strong> in the comment section of each file. Next, go to the <em>sp_home.html</em> file and within the document <code>head</code>, create links to the <em>sp_base.css</em>, <em>sp_styles.css</em>, and <em>sp_layout.css</em> style sheet files.</p>
    <h2>Window and Body Styles</h2>
    <p>Open the <em>sp_layout.css</em> file. Go to the "Window and Body Styles" section. Create a style rule for the <code>html</code> element that sets the <code>height</code> of the browser window at <strong>100%</strong>. Create a style rule for the page <code>body</code> that sets the <code>width</code> to <strong>95%</strong> of the browser window ranging from <strong>640</strong> pixels up to <strong>960</strong> pixels. Horizontally center the page <code>body</code> within the browser window. Karen wants to ensure that the height of the page body is always at least as high as the browser window itself. Set the minimum height of the browser window to <strong>100%</strong>. Finally, add a style rule to display all inline images as blocks.</p>
    <h2>CSS Grid Styles</h2>
    <p>Within the "CSS Grid Styles" section create a style rule that displays the <code>body</code> element as a grid with four columns of <code>length</code> <strong>1fr</strong>. Create a style rule for the <code>img</code> element with id <code>logo</code> so that the logo image spans three columns and has a <code>width</code> of <strong>100%</strong>. For the horizontal navigation list and the <code>footer</code> element create a style rule so that those elements span four columns. Create a style for the <code>aside</code> element to span two columns.</p>
    <h2>Horizontal Navigation List Styles</h2>
    <p>Within the "Horizontal Navigation List Styles" section create a style rule for <code>li</code>elements nested within the horizontal navigation list that display each element as a block with a <code>width</code> of <strong>12.5%</strong> and floated on the left margin.</p>
    <h2>Section Styles</h2>
    <p>Within the "Section Styles" section create a style rule for inline images within the <code>section</code> element that sets the <code>width</code> of the image to <strong>50%</strong> and centers the image using a top/bottom margin of <strong>0</strong> and a left/right margin of <strong>auto</strong>.</p>
    <p>Create a style rule for paragraphs within the <code>section</code> element that sets the <code>width</code>of the paragraph to <strong>70%</strong> and centers the paragraph using a top/bottom margin of <strong>0</strong>and a left/right margin of <strong>auto</strong>.</p>
    <h2>Customer Comment Styles</h2>
    <p>Go to the "Customer Comment Styles" section and create a style rule for the <code>aside</code> element setting the <code>width</code> to <strong>75%</strong>and the bottom padding to <strong>30</strong> pixels. The six <code>aside</code> elements will be displayed in two columns. For odd-numbered aside elements, use the <code>justify-self</code> grid property to place the element on the end (right) margin.</p>
    <blockquote class="info">
        <p>Use the <code>nth-of-type(odd)</code> pseudo-class to select the odd-numbered <code>aside</code>elements.</p>
    </blockquote>
    <p>Float inline images nested within the <code>aside</code> element on the left with a <code>width</code>of <strong>20%</strong> and float paragraphs nested within the <code>aside</code> element on the left with a <code>width</code> of <strong>75%</strong> and a left margin of <strong>5%</strong>.</p>
</div>
