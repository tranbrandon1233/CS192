# t3-review
<h2>Summary</h2>
<p>Anne wants you to work on another page for the Pandaisia Chocolates website. This page will contain information on some of the specials offered by the company in March; it will also display a list of some awards that the company has won. As you work on the page, you will use clip art images as placeholders until photographs of the awards are available. A preview of the completed page is shown in <em>Figure 3&ndash;83</em>.</p>
<p>&nbsp;</p>
<figure>
    <a class="markdown-image-link" title="Open image in a new tab" href="https://cdn.filestackcontent.com/OyOtTydQ5SwOBZZUaD0j" target="_blank" rel="noopener">
        <img src="https://cdn.filestackcontent.com/OyOtTydQ5SwOBZZUaD0j" alt="A Homepage of Pandaisia Chocolates. The page header displays the heading, Pandaisia Chocolates with the restaurant logo at the top right. Six links, Home, The Store, My Account, Special, Review, and Contact us are presented below the page header. At the left pane below the links, the subheading titled, &ldquo;March specials&rdquo; displays a descriptive paragraph. Below the paragraph, three nested grids show photos of different chocolates along with info are outlined. The awards of the store are displayed at the right pane. " />
    </a>
</figure>
<h2><sup><em>Figure 3-83</em></sup></h2>
<p>&nbsp;</p>
<p>Anne has already created the page content and some of the design styles to be used in the page. Your job will be to come up with the CSS style sheet to set the page layout.</p>
<h2>Document Setup</h2>
<p>Open the <em>pc_specials.html</em> and <em>pc_specials.css</em> files and enter your <strong>name</strong>and the <strong>date</strong> in the comment section of each file.</p>
<p>Next, open to the <em>pc_specials.html</em> file and within the document <code>head</code>, create links to the <em>pc_reset2.css</em>, <em>pc_styles4.css</em>, and <em>pc_specials.css</em> style sheets.</p>
<h2>Page Body Styles</h2>
<p>Go to the <em>pc_specials.css</em> file and within the "Page Body Styles" section, add a style rule for the <code>body</code> element that sets the <code>width</code> of the page body to <strong>95%</strong> of the browser window width within the range of <strong>640</strong> to <strong>960</strong> pixels. Horizontally center the page body within the window by setting the left and right margins to <strong>auto</strong>.</p>
<h2>Image Styles</h2>
<p>Go to the "Image Styles" section and create a style rule that displays all <code>img</code>elements as blocks with a <code>width</code> of <strong>100%</strong>.</p>
<h2>Horizontal Navigation Styles</h2>
<p>Anne wants the navigation list to be displayed horizontally on the page. Go to the "Horizontal Navigation Styles" section and create a style rule for every list item within a horizontal navigation list that displays the list item as a block floated on the left margin with a <code>width</code> of <strong>16.66%</strong>.</p>
<p>Display every hypertext link nested within a navigation list item as a block.</p>
<h2>Grid Styles</h2>
<p>Next, you will create the grid styles for the March Specials page. Go to the "Grid Styles" section and create a style rule for the <code>body</code> element that displays the element as a grid with two columns in the proportion of 2:1 (using <strong>fr</strong> units) with a column grid gap of <strong>20</strong> pixels.</p>
<p>Create a style rule for the <code>header</code> and <code>footer</code> elements that has both elements span the grid columns from the gridline number <strong>1</strong> to gridline number <strong>-1</strong>.</p>
<p>Create a style rule for the <code>section</code>element with the id <code>sub</code> that displays that element as a grid consisting of three columns of equal width by repeating the column width <strong>1fr</strong> three times.</p>
<h2>Special Styles</h2>
<p>Go to the "Specials Styles" section. In this section, you will create styles for the monthly specials advertised by the company. Create a style rule for all <code>div</code>elements of the <code>specials</code> class that sets the minimum height to <strong>400</strong> pixels and adds a <strong>1</strong> pixel dashed outline around the element with a color value of <strong>rgb(71, 52, 29)</strong>.</p>
<h2>Award Styles</h2>
<p>Go to the "Award Styles" section. In this section, you will create styles for the list of awards won by Pandaisia Chocolates. Information boxes for the awards are placed within an <code>aside</code> element.</p>
<p>Create a style rule for the <code>aside</code> element that places it using relative positioning, sets its <code>height</code> to <strong>650</strong> pixels, and automatically displays scrollbars for any overflow content.</p>
<p>Every information box in the <code>aside</code>element is stored in a <code>div</code> element. Create a style rule that places these elements with absolute positioning and sets their <code>width</code> to <strong>30%</strong>.</p>
<p>Position the individual awards within the awardList box by creating style rules for the <code>div</code> elements with id values ranging from <code>award1</code> to <code>award5</code> at the following (top, left) coordinates:</p>
<ol>
    <li><code>award1</code> <strong>(80px, 5%)</strong>,</li>
    <li><code>award2</code> <strong>(280px, 60%)</strong>,</li>
    <li><code>award3</code> <strong>(400px, 20%)</strong>,</li>
    <li><code>award4</code> <strong>(630px, 45%)</strong>,</li>
    <li><code>award5</code> <strong>(750px, 5%)</strong>.</li>
</ol>
<blockquote class="info">
    <p>In the <em>pc_specials.html</em> file, the five awards have been placed in a <code>div </code>element belonging to the <code>awards</code> class with id values ranging from <code>award1</code> to <code>award5</code>.</p>
</blockquote>
