# t4-code-2
<h2>Summary</h2>
<p><em>Figure 4&ndash;65</em> shows a web page containing text of a poem by Ella Wheeler Wilcox entitled &ldquo;Dawn.&rdquo; To augment the poem, a background image containing a linear gradient has been added to the web page. In addition, text shadows have been added to bring the text of the poem out of the page.</p>
<p>&nbsp;</p>
<figure>
    <a class="markdown-image-link" title="Open image in a new tab" href="https://cdn.filestackcontent.com/4QhOYVOvSIiqYl4x6eKg" target="_blank" rel="noopener">
        <img src="https://cdn.filestackcontent.com/4QhOYVOvSIiqYl4x6eKg" alt="A webpage displays a poem titled &ldquo;Dawn&rdquo; by Ella Wheeler Wilcox. " />
    </a>
</figure>
<p><sup><em>Figure 4-65</em></sup></p>
<p>&nbsp;</p>
<p>Do the following:</p>
<p>
    <span>Tasks</span>
</p>
<p>
    <span>Open the file <em>code4-2.html</em> and <em>code4-2_grad.css</em> and in the comment section enter your <strong>name</strong> <strong>(First + Last</strong>) and the <strong>date</strong>(<strong>MM/DD/YYYY</strong>) into the <code>Author:</code> and <code>Date:</code> fields of each file.</span>
</p>
<p>
    <span>Go to the <em>code4-2.html</em> file and within the <code>head</code> section insert a <code>link</code> element linking the page to the <em>code4-2_grad.css</em> file.</span>
</p>
<p>Open the <em>code4-2_grad.css</em> file. Create a style rule for the <code>article</code> element that adds a black inset box shadow with a horizontal and vertical offset of <strong>0</strong>pixels, a blur radius of <strong>50</strong> pixels and a size of <strong>20</strong> pixels.</p>
<p>Create a style rule for the <code>article</code> element that sets the radius of the border corners to <strong>150</strong> pixels.</p>
<p>Add the following multiple backgrounds:</p>
<ol>
    <li>A background containing the image file <em>landscape.png</em>placed with no tiling at the bottom right corner of the element with a size of <strong>100%</strong>.</li>
    <li>A linear gradient at an angle of <strong>165</strong> degrees that goes from <strong>black</strong> to the color value <strong>rgb(0, 0, 200)</strong> with a color stop of <strong>65%</strong>, to <strong>rgb(211, 0, 55)</strong> with a color stop of <strong>75%</strong>, to <strong>orange</strong> with a color stop of <strong>80%</strong>, and finally to <strong>yellow</strong>with a color stop of <strong>82%</strong>.</li>
</ol>
<p>
    <span>While working in the the </span><em>code4-2_grad.css</em>
    <span> file, create a style rule for </span><code>h1</code>
    <span> and </span><code>h2</code>
    <span> elements that adds a </span><strong>white</strong>
    <span> text shadow </span><strong>2</strong>
    <span>pixels above and to the left of the text with a blur radius of </span><strong>3</strong>
    <span> pixels.</span>
</p>
<p>
    <span>Create a style rule for paragraphs that adds a <strong>red</strong> text shadow <strong>2</strong>pixels down and to the right of the text with a blur radius of <strong>3</strong>pixels.</span>
</p>
<p>
    <span>Open the page in your browser and verify that the design resembles that shown in <em>Figure 4&ndash;65</em>.</span>
</p>
