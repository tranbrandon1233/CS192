# t6-code-1
<div class="custom-markdown steps-contents">
    <div class="step-block-outer step-block--not-last">
        <div class="step-block-header" role="heading" aria-level="2">
            <div class="custom-markdown steps-contents">
                <h2>Summary</h2>
                <p>The Orangeville Public Library has four conference rooms that it makes available for public use daily. You&rsquo;ve been asked to create a web page showing the room reservations for February 5, 2021. Use HTML table elements and CSS table styles to create the table shown in <em>Figure 6&ndash;48</em>.</p>
                <p>&nbsp;</p>
                <figure>
                    <a class="markdown-image-link" title="Open image in a new tab" href="https://cdn.filestackcontent.com/9wpoB0JKQeWulU3R497P" target="_blank" rel="noopener">
                        <img src="https://cdn.filestackcontent.com/9wpoB0JKQeWulU3R497P" alt="A webpage displays the conference room reservation table for February 5, 2021. The table has 10 columns and 4 rows. The column headers read, Conference room, 8.00 a m, 9.00 a m, 10.00 a m, 11.00 a m, 12.00 a m, 1.00 p m, 2.00 p m, 3.00 p m, and 4.00 p m. The row element contains the names of the different conference rooms and names of the classes." />
                    </a>
                </figure>
                <sup><em>Figure 6-48</em></sup>
                <p>&nbsp;</p>
                <p>Do the following:</p>
            </div>
            <div class="step-block-outer step-block--not-last">
                <div class="step-block-header" role="heading" aria-level="2">Tasks</div>
                <div class="step-block-header" role="heading" aria-level="2">
                    <br />
                    <span>Open the files </span><em>code6-1.html</em>
                    <span> and </span><em>code6-1_table.css</em>
                    <span> and in the comment section enter your </span><strong>name</strong>
                    <span> (First + Last) and the </span><strong>date&nbsp;</strong>
                    <span>(MM/DD/YYYY) into the </span><code>Author:</code>
                    <span> and </span><code>Date:</code>
                    <span> fields of each file.</span>
                </div>
                <div class="step-block-header" role="heading" aria-level="2">
                    <br />
                    <span>Go to the </span><em>code6-1.html</em>
                    <span> file and within the </span><code>head</code>
                    <span> section insert </span><code>link</code>
                    <span> elements linking the page to the </span><em>code6-1_layout.css</em>
                    <span>and </span><em>code6-1_table.css</em>
                    <span> files.</span>
                </div>
                <div class="step-block-header" role="heading" aria-level="2">
                    <br />
                    <p>Below the <code>body header</code>, create a table using the <code>table</code>element. Add the following features to the table:</p>
                    <ol>
                        <li>Insert a <code>caption</code>containing the text <strong>February 5, 2021</strong>.</li>
                        <li>Insert a column group containing a column with the id <code>firstCol</code> and a column with the id <code>hourCols</code> that spans <strong>9</strong>columns.</li>
                        <li>Insert a table head group that contains a single row with <code>th</code> elements containing the text <strong>Conference Room</strong> and the times <strong>8:00am</strong> through <strong>4:00pm</strong> in one-hour increments.</li>
                        <li>Insert a table body group that contains the four rows shown in <em>Figure 6&ndash;48</em> for each of the four conference rooms. Within each row insert a <code>th</code> element containing the name of the conference room. Following that <code>th</code> cell insert the groups reserving the room in <code>td</code> elements. If a group has reserved a room for longer than an hour, have the <code>td</code> cell span the number of columns for that reservation.</li>
                    </ol>
                    <p>Open the <em>code6-1_table.css</em> file and create the following style rules for the indicated elements:</p>
                    <ol>
                        <li>For the <code>table</code> element: Add a <strong>20</strong> pixel <strong>grooved gray</strong> border and collapse the table borders.</li>
                        <li>For the <code>th</code> and <code>td</code>elements: Add a <strong>1</strong> pixel <strong>solid gray</strong> border, set the padding space to <strong>5</strong> pixels, and align the cell content with the top-left corner of the cell.</li>
                        <li>For the <code>caption</code> element, set the display the caption at the top-left of the table and set the font size of the caption text to <strong>1.5em</strong>.</li>
                        <li>For <code>col</code> element with the id <code>firstCol</code>, change the background color to <strong>yellow</strong>and set the column <code>width</code>to <strong>150</strong> pixels.</li>
                        <li>For <code>col</code> element with the id <code>hourCols</code>, set the column <code>width</code> to <strong>75</strong> pixels.</li>
                        <li>Change the background color of the <code>thead</code>element to <strong>aqua</strong>.</li>
                    </ol>
                    <p>
                        <span>Verify that the layout of the table resembles that shown in </span><em>Figure 6&ndash;48</em>
                        <span>.</span>
                    </p>
                </div>
            </div>
