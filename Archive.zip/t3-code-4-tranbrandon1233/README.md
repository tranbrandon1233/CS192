<h1>T3 Coding Challenge 4</h1>
<div class="custom-markdown steps-contents">
    <h2>Summary</h2>
    <p><em>Figure 3&ndash;82</em>
        <span>&nbsp;</span>shows a completed web page that uses CSS to design the page layout. You&rsquo;ve been given the initial HTML and CSS code for this web page, but there are several errors in the CSS stylesheet. Use your knowledge of CSS to locate and fix the errors.
    </p>
    <p>&nbsp;</p>
    <figure>
        <a class="markdown-image-link" title="Open image in a new tab" href="https://cdn.filestackcontent.com/aWpZeZbOR3qmhD6M6acV" target="_blank" rel="noopener">
            <img src="https://cdn.filestackcontent.com/aWpZeZbOR3qmhD6M6acV" alt="A webpage of Red Ball Pizza with an image of pizza is displayed. The address, 8 1 1 Beach drive, Ormond Beach, FL 3 2 1 7 5 (3 8 6) 555 hyphen 7 4 9 9 are present at the top right of the page. Five options, home, menu, locations, catering, about us are displayed below the header. A pane at the left displays the list of menu items. A pane at the right displays two descriptive paragraphs with pizza offers at the bottom. The information about the pizza pizzazz is displayed at the right of two descriptive paragraphs." />
        </a>
    </figure>
    <sup><em>Figure 3-82</em></sup>
    <p>&nbsp;</p>
    <p>Do the following:</p>
</div>
<div class="step-block-outer step-block--not-last">
    <div class="step-block-header" role="heading" aria-level="2"><strong>Tasks</strong></div>
    <div class="step-block-header" role="heading" aria-level="2">
        <span>Open the files&nbsp;</span><em>code3-4.html</em>
        <span>&nbsp;and&nbsp;</span><em>debug3-4.css</em>
        <span>&nbsp;and enter your&nbsp;</span><strong>name</strong>
        <span>&nbsp;and the&nbsp;</span><strong>date</strong>
        <span>&nbsp;into the&nbsp;</span><code>head</code>
        <span>&nbsp;section of the document.</span>
    </div>
    <br />
    <div class="step-block-header" role="heading" aria-level="2">
        <span>Go to the&nbsp;<em>code3-4.html</em>&nbsp;file. Link the page to the&nbsp;<em>debug3-4.css</em>&nbsp;style sheet file.</span>
    </div>
    <div class="step-block-header" role="heading" aria-level="2">
        <p>Open the<span>&nbsp;</span><em>debug3-4.css</em>
            <span>&nbsp;</span>file. The<span>&nbsp;</span><code>body</code>
            <span>&nbsp;</span>element should have a<span>&nbsp;</span><code>width</code>
            <span>&nbsp;</span>that is<span>&nbsp;</span><strong>90%</strong>
            <span>&nbsp;</span>of the<span>&nbsp;</span><code>width</code>
            <span>&nbsp;</span>of the browser window ranging from a minimum of<span>&nbsp;</span><strong>600</strong>
            <span>&nbsp;</span>pixels up to a maximum of<span>&nbsp;</span><strong>1024</strong>
            <span>&nbsp;</span>pixels. Fix the syntax errors in the body style rule that defines the width of the web page.
        </p>
        <p>The style rule for the<span>&nbsp;</span><code>body</code>
            <span>&nbsp;</span>element sets up a grid layout for the page. However, there are several errors in defining the grid areas, grid columns, and grid gaps. Fix the syntax errors in the style rule.
        </p>
        <p>
            <span>Go to the style rules in the "Grid Areas" section that assigns page elements to areas of the grid. Locate and fix the errors in assigning elements to grid areas.</span>
        </p>
        <p>
            <span>The style rules for the horizontal navigation list and the&nbsp;<code>section</code>&nbsp;element also define grid styles for those elements. Locate and fix errors in the code that set up the grid columns.</span>
        </p>
        <p>
            <span>The last paragraph within the&nbsp;<code>section</code>&nbsp;<code>div</code>&nbsp;selector should be placed with absolute positioning&nbsp;<strong>1</strong>&nbsp;pixel and&nbsp;<strong>5</strong>&nbsp;pixels from the bottom right corner of the container element. However, there is an error in defining the selector. Find and fix the error.</span>
        </p>
        <p>
            <span>Open the website in the browser preview and verify that design of the page resembles that shown in&nbsp;<em>Figure 3&ndash;82</em>.</span>
        </p>
    </div>
</div>
