# t4-code-1
<div class="custom-markdown steps-contents">
    <h2>Summary</h2>
    <p><em>Figure 4&ndash;64</em> shows a web page containing text from a Shakespearean sonnet. In this Coding Challenge you will augment the text of the poem with background colors and images and add a graphic border.</p>
    <p>&nbsp;</p>
    <figure>
        <a class="markdown-image-link" title="Open image in a new tab" href="https://cdn.filestackcontent.com/kOCwWduQqCbaZM9WUaQk" target="_blank" rel="noopener">
            <img src="https://cdn.filestackcontent.com/kOCwWduQqCbaZM9WUaQk" alt="A webpage displays a poem in four paragraphs titled, &ldquo;Sonnet 116&rdquo; with an image of William Shakespeare at the bottom right of the page." />
        </a>
    </figure>
    <p>&nbsp;</p>
    <p><sup><em>Figure 4-64</em></sup></p>
    <p>Do the following:</p>
</div>
<div class="step-block-outer step-block--not-last">
    <div class="step-block-header" role="heading" aria-level="2">Tasks</div>
    <div class="step-block-header" role="heading" aria-level="2">
        <span>Open the file </span><em>code4-1.html</em>
        <span> and </span><em>code4-1_back.css</em>
        <span> and in the comment section enter your </span><strong>name</strong>
        <span> (First + Last) and the </span><strong>date</strong>
        <span>(MM/DD/YYYY) into the </span><code>Author:</code>
        <span>and </span><code>Date:</code>
        <span> fields of each file.</span>
    </div>
    <div class="step-block-header" role="heading" aria-level="2">
        <span>
            <br />Go to the <em>code4-1.html</em> file and within the <code>head</code> section insert a <code>link</code> element linking the page to the <em>code4-1_back.css</em> style sheet file.
        </span>
    </div>
    <div class="step-block-header" role="heading" aria-level="2">
        <span>
            <br />Enclose the content of the sonnet within a <code>figure</code> element. At the top of the <code>figure</code> element and before the first <code>p</code> element, insert a <code>figcaption</code> containing the HTML code <strong>Sonnet 116 <code>&lt;cite&gt;</code>by William Shakespeare<code>&lt;/cite&gt;</code></strong>.
        </span>
    </div>
    <div class="step-block-header" role="heading" aria-level="2">
        <p>Open the <em>code4-1_back.css</em> file and create a style rule for the <code>figure</code> element that:</p>
        <ol>
            <li>Sets the padding space to <strong>20</strong>pixels.</li>
            <li>Adds a <strong>20</strong>-pixel border in the ridge style with the color value <strong>rgb(52, 52, 180)</strong>.</li>
            <li>Has a background consisting of the image file <em>ws.png</em>placed in the bottom right corner of the <code>figure</code> box and set to <strong>45%</strong> of the <code>width</code>of the <code>figure</code> box with no tiling. Be sure to separate the position of the image and its size with the / character. Add a second background containing the color <strong>rgba(52, 52, 180, 0.3)</strong>. Enter both background properties within a single style rule separated by a comma.</li>
            <li>Has a black box shadow that is <strong>5</strong> pixels to the right, <strong>10</strong>pixels down with a blur size of <strong>15</strong> pixels.</li>
        </ol>
        <p>Within the <em>code4-1_back.css</em> file create a style rule for the <code>figcaption</code> that:</p>
        <ol>
            <li>Sets the font size to <strong>1.8em</strong>.</li>
            <li>Centers the text of the caption.</li>
            <li>Adds a <strong>2</strong> pixel bottom solid bottom border of the color value <strong>rgb(52, 52, 180)</strong>.</li>
        </ol>
        <p>
            <span>Open the page in the browser preview and verify that the design resembles that shown in </span><em>Figure 4&ndash;64</em>
            <span>.</span>
        </p>
    </div>
</div>
