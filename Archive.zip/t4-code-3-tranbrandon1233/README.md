# t4-code-3
<div class="custom-markdown steps-contents">
    <h2>Summary</h2>
    <p><em>Figure 4&ndash;66</em> shows a web page in which five faces of the cube are displayed in a 3D view. You can create this effect using the CSS 3D transformation styles. The page also contains CSS styles for box shadows and text shadows that you will have to add.</p>
    <p>&nbsp;</p>
    <figure>
        <a class="markdown-image-link" title="Open image in a new tab" href="https://cdn.filestackcontent.com/zTAkG16TgSBYlgdwvche" target="_blank" rel="noopener">
            <img src="https://cdn.filestackcontent.com/zTAkG16TgSBYlgdwvche" alt="A webpage displays an image titled &ldquo;Classical Sketches.&rdquo; The image shows the inner surface of a cube on which five sketches are displayed with one sketch each on the back, top, bottom, left and right faces. " />
        </a>
    </figure>
    <sup><em>Figure-66</em></sup>
    <p>&nbsp;</p>
    <p>Do the following:</p>
</div>
<div class="step-block-outer step-block--not-last">
    <div class="step-block-header" role="heading" aria-level="2">Tasks</div>
    <div class="step-block-header" role="heading" aria-level="2">
        <span>Open the file </span><em>code4-3.html</em>
        <span> and </span><em>code4-3_cube.css</em>
        <span> and in the comment section enter your </span><strong>name</strong>
        <span> (First + Last) and the </span><strong>date</strong>
        <span>(MM/DD/YYYY) into the </span><code>Author:</code>
        <span>and </span><code>Date:</code>
        <span> fields of each file.</span>
    </div>
    <div class="step-block-header" role="heading" aria-level="2">
        <span>
            <br />Go to the <em>code4-3.html</em> file and within the <code>head</code>section insert a <code>link</code> element that links the page to the <em>code4-3_cube.css</em> style sheet file. Note that within the web page the five images are contained with a <code>div</code> element with the ID value <code>cube</code>. The images are given ID values of <code>img1</code> through <code>img5</code>.
        </span>
    </div>
    <div class="step-block-header" role="heading" aria-level="2">
        <span>
            <br />Open to the <em>code4-3_cube.css</em> file and create a style rule for the <code>h1</code>element that changes the font color to <strong>white</strong> and adds a text shadow with horizontal and vertical offsets of <strong>0</strong> pixels, a blur radius of <strong>20</strong> pixels and a shadow color value of <strong>rgb(120, 85, 0)</strong>.
        </span>
    </div>
    <div class="step-block-header" role="heading" aria-level="2">
        <span>
            <br />Create a style rule for a <code>div</code>element with the id <code>cube</code> that sets the perspective size of the 3D space to <strong>500</strong> pixels. Use the <code>transform-style</code> property to preserve the 3D setting for the children of this element so that the cube and its children exist in the same 3D space.
        </span>
    </div>
    <div class="step-block-header" role="heading" aria-level="2">
        <span>
            <span>
                <br />
            </span>
        </span>
        <p>For all <code>img</code> elements create a style rule that applies a <strong>sepia</strong>filter with a value of <strong>1</strong>. Add a <strong>black</strong> box shadow with horizontal and vertical offsets of <strong>0</strong> pixels and a blur radius of <strong>20</strong>pixels.</p>
        <p>Create the following style rules for the five image elements:</p>
        <ol>
            <li>For the <code>img1</code> image, translate the image <strong>-150</strong>pixels along the z-axis.</li>
            <li>For the <code>img2</code> image, rotate the image <strong>90</strong> degrees around the x-axis and translate the image <strong>-150</strong> pixels along the z-axis.</li>
            <li>For the <code>img3</code> image, rotate the image <strong>-90</strong> degrees around the y-axis and translate the image <strong>150</strong>pixels along the z-axis.</li>
            <li>For the <code>img4</code> image, rotate the image <strong>90</strong> degrees around the y-axis and translate the image <strong>150</strong> pixels along the z-axis.</li>
            <li>For the <code>img5</code> image, rotate the image <strong>-90</strong> degrees around the x-axis and translate the image <strong>-150</strong>pixels along the z-axis.</li>
        </ol>
        <p>
            <span>Open the page in your browser and verify that the design resembles that shown in </span><em>Figure 4&ndash;66</em>
            <span>.</span>
        </p>
    </div>
</div>
