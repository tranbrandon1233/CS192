# t4-code-4
<div class="custom-markdown steps-contents">
    <h2>Summary</h2>
    <p><em>Figure 4&ndash;67</em> shows a completed web page that uses CSS design elements to enhance the appearance of a poem by Walt Whitman. You&rsquo;ve been given a copy of the files for this web page, but there are several syntax errors in the CSS stylesheet. Use your knowledge of CSS to fix the stylesheet code and complete the page</p>
    <p>&nbsp;</p>
    <figure>
        <a class="markdown-image-link" title="Open image in a new tab" href="https://cdn.filestackcontent.com/FIBdtDprRyykZJaKqFog" target="_blank" rel="noopener">
            <img src="https://cdn.filestackcontent.com/FIBdtDprRyykZJaKqFog" alt="A webpage displays a poem titled &ldquo;I Sing the Body Electric&rdquo; by Walt Whitman." />
        </a>
    </figure>
    <sup><em>Figure 4-67</em></sup>
    <p>&nbsp;</p>
    <p>Do the following:</p>
</div>
<div class="step-block-outer step-block--not-last">
    <div class="step-block-header" role="heading" aria-level="2">Tasks</div>
    <div class="step-block-header" role="heading" aria-level="2">
        <span>Open the </span><em>code4-4.html</em>
        <span> and </span><em>debug4-4.css</em>
        <span> files and in the comment section enter your </span><strong>name</strong>
        <span> (First + Last) and the </span><strong>date</strong>
        <span>(MM/DD/YYYY) into the </span><code>Author:</code>
        <span>and </span><code>Date:</code>
        <span> fields of each file.</span>
    </div>
    <div class="step-block-header" role="heading" aria-level="2">
        <span>
            <br />Go to the <em>code4-4.html</em> file and within the <code>head</code> section insert a <code>link</code> element that links the page to the <em>debug4-4.css</em> style sheet file.
        </span>
    </div>
    <div class="step-block-header" role="heading" aria-level="2">
        <span>
            <br />Go to the <em>debug4-4.css</em> file in your browser. The first style rule adds two text shadows to the <code>h1</code> heading: a dark <strong>brown</strong>shadow and a <strong>white</strong> highlight. The shadows are not appearing in the web page. Locate and fix the syntax error in this style rule.
        </span>
    </div>
    <div class="step-block-header" role="heading" aria-level="2">
        <span>
            <br />The next style rule was written to add a box shadow to the <code>article</code> element that has an offset of <strong>0</strong> pixels in the horizontal and vertical directions, blur radius of <strong>30</strong> pixels and size value of <strong>5</strong> pixels. Fix the syntax errors in this style rule.
        </span>
    </div>
    <div class="step-block-header" role="heading" aria-level="2">
        <span>
            <br />The next style rule creates a border image for the <code>article</code>element using a linear gradient for the image. Fix the syntax error in this style rule.
        </span>
    </div>
    <div class="step-block-header" role="heading" aria-level="2">
        <span>
            <span>
                <br />
            </span>
        </span>
        <p>The final style rule defines the background for the <code>article</code>element consisting of:</p>
        <ol>
            <li>A radial gradient going from <strong>white</strong> circle located near the top left corner of the background, to semi-transparent <strong>yellow</strong>, semi-transparent <strong>brown</strong>, and semi-transparent <strong>ochre</strong>.</li>
            <li>A sketch by Michelangelo located in the lower right corner sized at <strong>75%</strong> of the <code>width</code> of the element.</li>
            <li>
                <p>An ivory-colored background fill.</p>
                <p>There are several syntax errors in the code. Locate and fix all of the errors.</p>
            </li>
        </ol>
        <p>
            <span>Open the website in the browser preview and verify that design of the page resembles that shown in </span><em>Figure 4&ndash;67</em>
            <span>.</span>
        </p>
        <p>&nbsp;</p>
    </div>
</div>
