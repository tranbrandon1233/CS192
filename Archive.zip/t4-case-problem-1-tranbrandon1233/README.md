# t4-case-problem-1
<h2>Summary</h2>
<p><strong>Save your Fork</strong> - Amy Wu has asked for your help in redesigning her website, Save your Fork, a baking site for people who want to share dessert recipes and learn about baking in general. She has prepared a page containing a sample dessert recipe and links to other pages on the website. A preview of the page you&rsquo;ll create is shown in <em>Figure 4&ndash;70</em>.</p>
<p>&nbsp;</p>
<figure>
    <a class="markdown-image-link" title="Open image in a new tab" href="https://cdn.filestackcontent.com/VzZY2iq0RKu76mZH8crO" target="_blank" rel="noopener">
        <img src="https://cdn.filestackcontent.com/VzZY2iq0RKu76mZH8crO" alt="A home page preview of Save your Fork sample recipe website. Seven tabs listed below the heading, are: recipes, menus, holidays, market, shopping, columns and messages. The categories and related recipes are displayed at the left pane and the reviews of the page are displayed on the right pane.  At center pane, a photo of the dish with the title &ldquo;Apple Bavarian Torte&rdquo; by Lemking is displayed along with the description of the dish. Below, Ingredients, recipe box, and directions are given." />
    </a>
</figure>
<p><sup><em>Figure 4-70</em></sup></p>
<p>&nbsp;</p>
<p>Amy has already created a style sheet for the page layout and typography, so your work will be focused on enhancing the page with graphic design styles.</p>
<h2>Document Setup</h2>
<p>Open the <em>sf_torte.html</em> and <em>sf_effects.css</em>files and enter your <strong>name</strong> and the <strong>date</strong> in the comment section of each file. Next, go to the <em>sf_torte.html</em> file in your editor. Within the document <code>head</code> create links to the <em>sf_base.css</em>, <em>sf_layout.css</em>, and <em>sf_effects.css</em> style sheet files in that order. Take some time to study the structure of the document and then close the document.</p>
<h2>Body Header Styles</h2>
<p>Go to the <em>sf_effects.css</em> file and within the "Body Header Styles" section, create a style rule for the <code>body</code> element to add drop shadows to the left and right border of the page body with an offset of <strong>10</strong> pixels, a blur of <strong>50</strong> pixels, and the color <strong>rgb(51, 51, 51)</strong>. Note that the right border is a mirror image of the left border.</p>
<h2>Navigation Tabs List Styles</h2>
<p>Go to the "Navigation Tabs List Styles" section. Amy has created a navigation list with the class name <code>tabs</code> that appears at the top of the page with the <code>body header</code>. Create a style rule for the <code>body &gt; header nav.tabs</code> selector that changes the background to the image file <em>sf_back1.png</em> with no tiling, centered horizontally and vertically within the element and sized to cover the entire navigation list.</p>
<p>Amy wants the individual list items in the tabs navigation list to appear as tabs in a recipe box. She wants each of these &ldquo;tabs&rdquo; to be trapezoidal in shape. To create this effect, you&rsquo;ll create a style rule for the <code>body &gt; header nav.tabs li</code> selector that transforms the list item by setting the perspective of its 3D space to <strong>50</strong> pixels and rotating it <strong>20&deg;</strong> around the x-axis.</p>
<p>As users hover the mouse pointer over the navigation tabs, Amy wants a rollover effect in which the tabs appear to come to the front. Create a style rule for the <code>body &gt; header nav.tabs li</code> selector that uses the pseudo-element <code>hover</code> that changes the background color to <strong>rgb(231, 231, 231)</strong>.</p>
<h2>Left Section Styles</h2>
<p>Go to the "Left Section Styles" section. Referring to <em>Figure 4&ndash;70</em>, notice that in the left section of the page, Amy has placed two vertical navigation lists. She wants these navigation lists to have rounded borders. For the vertical navigation lists in the left section, create a style rule for the <code>section#left nav.vertical</code> selector that adds a <strong>1</strong> pixel solid border with color value <strong>rgb(20, 167, 170)</strong> and has a radius of <strong>25</strong> pixels at each corner.</p>
<p>The rounded corner also has to apply to the <code>h1</code> heading within each navigation list. Create a style rule for <code>h1</code> elements nested within the left section vertical navigation list that sets the top-left and top-right corner radii to <strong>25</strong> pixels.</p>
<h2>Center Article Styles</h2>
<p>Go to the "Center Article Styles" section. The <code>article</code> element contains an image and brief description of the Apple Bavarian Torte, which is the subject of this sample page. Create a style rule for the <code>section#center article</code> selector that adds the following:</p>
<ol>
    <li>A radial gradient to the background with a <strong>white</strong> center with a color stop of <strong>30%</strong> transitioning to <strong>rgb(151, 151, 151)</strong>.</li>
    <li>A <strong>1</strong> pixel solid border with color value <strong>rgb(151, 151, 151)</strong> and a radius of <strong>50</strong>pixels.</li>
    <li>A box shadow with horizontal and vertical offsets of <strong>10</strong> pixels with a <strong>20</strong>pixel blur and a color of <strong>rgb(51, 51, 51)</strong>.</li>
</ol>
<h2>Blockquote Styles</h2>
<p>Go to the "Blockquote Styles" section. Amy has included three sample reviews from users of the Save your Fork website. Amy wants the text of these reviews to appear within the image of a speech bubble. For every <code>blockquote</code> element, create a style rule that does the following:</p>
<ol>
    <li>Set the background image to the <em>sf_speech.png</em> file with no tiling and a horizontal and vertical size of <strong>100%</strong> to cover the entire block quote.</li>
    <li>Use the <code>drop-shadow</code> filter to add a drop shadow around the speech bubble with horizontal and vertical offsets of <strong>5</strong> pixels, a blur of <strong>10</strong> pixels and the color <strong>rgb(51, 51, 51)</strong>.</li>
</ol>
<p>Amy has included the photo of each reviewer registered on the site within the citation for each review. She wants these images to appear as circles rather than squares. To do this, create a style rule for the selector <code>cite img</code> that sets the border radius to <strong>50%</strong>.</p>
