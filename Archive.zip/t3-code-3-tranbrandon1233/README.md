<h1>T3 Coding Challenge 3</h1>
<div class="custom-markdown steps-contents">
    <div class="custom-markdown steps-contents">
        <div class="custom-markdown steps-contents">
            <h2>Summary</h2>
            <p>You can use the CSS positioning and overflow styles to create a scrolling slideshow.<span>&nbsp;</span><em>Figure 3&ndash;81</em>
                <span>&nbsp;</span>shows an example of a slideshow consisting of nine sketches by Renaissance masters. You&rsquo;ve been given the HTML code for this document and you&rsquo;ve been asked to write the style rules to generate the slideshow.
            </p>
            <p>&nbsp;</p>
            <figure>
                <a class="markdown-image-link" title="Open image in a new tab" href="https://cdn.filestackcontent.com/VLrlzEVXQWDxlUUYpDGC" target="_blank" rel="noopener">
                    <img src="https://cdn.filestackcontent.com/VLrlzEVXQWDxlUUYpDGC" alt="A page titled, Artist Sketchbook displays three arts with their portraitist names as follows: Head of a Maid by Peter Paul Rubens, Women&rsquo;s Portrait by Andre del Sarto, and Shepherd Boy by Giovanni Battista Piazzetta. " />
                </a>
            </figure>
            <sup><em>Figure 3-81</em></sup>
            <p>&nbsp;</p>
            <p>Do the following:</p>
        </div>
        <div class="step-block-outer step-block--not-last">
            <div class="step-block-header" role="heading" aria-level="2"><strong>Tasks</strong></div>
            <div class="step-block-header" role="heading" aria-level="2">
                <span>Open the file&nbsp;</span><em>code3-3.html</em>
                <span>&nbsp;and&nbsp;</span><em>code3-3_scroll.css</em>
                <span>&nbsp;and in the comment section enter your&nbsp;</span><strong>name</strong>
                <span>&nbsp;(First + Last) and the&nbsp;</span><strong>date</strong>
                <span>&nbsp;(MM/DD/YYYY) into the&nbsp;</span><code>Author:</code>
                <span>&nbsp;and&nbsp;</span><code>Date</code>
                <span>: fields of each file.</span>
            </div>
            <div class="step-block-header" role="heading" aria-level="2">
                <span>
                    <br />Go to the&nbsp;<em>code3-3.html</em>&nbsp;file and within the&nbsp;<code>head</code>&nbsp;section insert the&nbsp;<code>link</code>&nbsp;element linking the&nbsp;<em>code3-3_scroll.css</em>&nbsp;style sheet file. Review the contents of the file.
                </span><br /><br />
            </div>
            <div class="step-block-header" role="heading" aria-level="2">
                <p>Go to the<span>&nbsp;</span><em>code_scroll.css</em>
                    <span>&nbsp;</span>file and create a style rule for the<span>&nbsp;</span><code>section</code>
                    <span>&nbsp;</span>element with the id<span>&nbsp;</span><code>container</code>
                    <span>&nbsp;</span>with the following styles:
                </p>
                <ol>
                    <li>Set the<span>&nbsp;</span><code>width</code>
                        <span>&nbsp;</span>of the element to<span>&nbsp;</span><strong>900</strong>
                        <span>&nbsp;</span>pixels and the<span>&nbsp;</span><code>height</code>
                        <span>&nbsp;</span>to<span>&nbsp;</span><strong>370</strong>
                        <span>&nbsp;</span>pixels.
                    </li>
                    <li>Horizontally center the element by adding a<span>&nbsp;</span><strong>10</strong>
                        <span>&nbsp;</span>pixel top/bottom margin and set the left/right margin to<span>&nbsp;</span><strong>auto</strong>.
                    </li>
                    <li>Place the element with relative positioning, setting the top value to<span>&nbsp;</span><strong>30</strong>
                        <span>&nbsp;</span>pixels and the left value to<span>&nbsp;</span><strong>0</strong>
                        <span>&nbsp;</span>pixels.
                    </li>
                    <li>Add a<span>&nbsp;</span><strong>2</strong>
                        <span>&nbsp;</span>pixel solid brown outline to the element.
                    </li>
                    <li>Have the browser automatically display scrollbars for any overflow content.</li>
                </ol>
                <p>
                    <span>Create a style rule for every&nbsp;</span><code>div</code>
                    <span>&nbsp;element, setting the&nbsp;</span><code>width</code>
                    <span>&nbsp;to&nbsp;</span><strong>300</strong>
                    <span>&nbsp;pixels and the&nbsp;</span><code>height</code>
                    <span>&nbsp;to&nbsp;</span><strong>330</strong>
                    <span>&nbsp;pixels. Position the element with&nbsp;</span><code>absolute</code>
                    <span>&nbsp;positioning. There are nine&nbsp;</span><code>div</code>
                    <span>&nbsp;elements with ids ranging from&nbsp;</span><code>slide1</code>
                    <span>&nbsp;to&nbsp;</span><code>slide9</code>
                    <span>. Set the left position of the elements in&nbsp;</span><strong>300</strong>
                    <span>&nbsp;pixel increments starting with&nbsp;</span><strong>0</strong>
                    <span>&nbsp;pixels for&nbsp;</span><code>slide1</code>
                    <span>,&nbsp;</span><strong>300</strong>
                    <span>&nbsp;pixels for&nbsp;</span><code>slide2</code>
                    <span>,&nbsp;</span><strong>600</strong>
                    <span>&nbsp;pixels for&nbsp;</span><code>slide3</code>
                    <span>, and so forth up to&nbsp;</span><strong>2400</strong>
                    <span>&nbsp;pixels for&nbsp;</span><code>slide9</code>
                    <span>.</span>
                </p>
                <p>
                    <span>Display every inline image as a block-level element with a&nbsp;<code>width</code>&nbsp;and&nbsp;<code>height</code>&nbsp;of&nbsp;<strong>300</strong>&nbsp;pixels.</span>
                </p>
                <p>
                    <span>Open the page in your browser. Verify that the nine images are displayed within a scroll box and that you can using a horizontal scrollbar to scroll through the image list.
                        <br />
                    </span>
                </p>
            </div>
        </div>
    </div>
</div>
