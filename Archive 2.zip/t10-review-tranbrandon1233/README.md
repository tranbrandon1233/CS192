# t10-review
<figure>
        <a class="markdown-image-link" title="Open image in a new tab" href="https://cdn.filestackcontent.com/Wooqdq9xToqtx43Hzpra" target="_blank" rel="noopener">
            <img src="https://cdn.filestackcontent.com/Wooqdq9xToqtx43Hzpra" alt="A home page of The Lyman Hall Theater website is displayed with a photo of a woman mime artist at the top left corner. Six tabs listed below the heading The Lyman Hall Theater is: home, events, box office, facilities, directions, and contact. The sub heading, At the Theater is shown below the tabs at the left accompanied by four descriptive paragraphs. The schedule of the upcoming events is displayed at the right of the description in the form of table. " />
        </a>

</figure>
<p>&nbsp;</p>
<h3>Summary</h3>
<p>Lewis wants you to write another script that shows a table of events at the Lyman Hall Theater over the next two weeks from the current date. He has already created three arrays for use with the script:</p>
<ul>
    <li>The <strong>eventDates</strong> <code>array</code> containing a list of dates and times at which theater events are scheduled.</li>
    <li>The <strong>eventDescriptions</strong> <code>array</code> containing the description of those events.</li>
    <li>The <strong>eventPrices</strong> <code>array</code> containing the admission prices of those events.</li>
</ul>
<p>Lewis has already written the page content and provided style sheets for use with the page. Your job will be to write a script that selects the events that occur in the two-week window from the current date and display them in the web page.</p>
<p>A preview of the home page is shown above.</p>
<p>The style sheets and graphic files have already been created for you. Your job is to write the HTML markup.</p>
<h3>Setup</h3>
<p>Enter <strong><em>your name</em></strong> and <strong><em>the date</em></strong> in the comment section of <strong>lht_events.html</strong> and <strong>lht_table.js</strong>.</p>
<h3>Link JS Files</h3>
<p>Open the <strong>lht_events.html</strong> file and directly above the closing <code>&lt;/head&gt;</code> tag, insert script elements that link the page to the <strong>lht_list.js</strong> and <strong>lht_table.js</strong> files in that order. Defer the loading and running of both script files until after the page has loaded.</p>
<h3>Event List</h3>
<p>Scroll down the document and directly after the closing <code>&lt;/article&gt;</code> tag insert a <code>div</code> element with the ID <strong>eventList</strong>. It is within this element that you will write the HTML code for the table of upcoming theater events.
    <br />(<em>Hint : Be sure to review this file and all the support files, noting especially the names of variables that you will be using in the code you create.</em>)
</p>
<div class="custom-markdown steps-contents">
    <h3>Variables</h3>
    <p>Go to the <strong>lht_table.js</strong> file and below the comment section, declare a variable named <strong>thisDay</strong> containing the date <strong>October 1, 2021</strong>. You will use this date to test your script.</p>
    <p>Create a variable named <strong>tableHTML</strong> that will contain the HTML code of the events table. Add the text of the following HTML code to the initial value of the variable:</p>
    <pre class="cmh-pre light"><code class="cmh" data-language="html"><span><span class="mtk1">&lt;</span><span class="mtk15">table</span><span class="mtk1">&nbsp;</span><span class="mtk15">id</span><span class="mtk20">=</span><span class="mtk29">'</span><span class="mtk1">eventTable</span><span class="mtk29">'</span><span class="mtk1">&gt;</span></span><br /><span><span class="mtk1">&lt;</span><span class="mtk15">caption</span><span class="mtk1">&gt;Upcoming&nbsp;Events&lt;/</span><span class="mtk15">caption</span><span class="mtk1">&gt;</span></span><br /><span><span class="mtk1">&lt;</span><span class="mtk15">tr</span><span class="mtk1">&gt;&lt;</span><span class="mtk15">th</span><span class="mtk1">&gt;Date&lt;/</span><span class="mtk15">th</span><span class="mtk1">&gt;&lt;</span><span class="mtk15">th</span><span class="mtk1">&gt;Event&lt;/</span><span class="mtk15">th</span><span class="mtk1">&gt;&lt;</span><span class="mtk15">th</span><span class="mtk1">&gt;Price&lt;/</span><span class="mtk15">th</span><span class="mtk1">&gt;&lt;/</span><span class="mtk15">tr</span><span class="mtk1">&gt;</span></span><br /></code></pre>
    <p>Lewis only wants the page to list events occurring within 14 days after the current date. Declare a variable named <strong>endDate</strong> that contains a <code>Date</code> object that is 14 days after the date stored in the <strong>thisDay</strong> variable.</p>
    <p><em>(Hint : Use the <code>new Date()</code> object constructor and insert a time value that is equal to <code>thisDay.getTime() + 14 x 24 x 60 x 60 x 1000</code>.)</em></p>
    <h3>For Loop</h3>
    <p>Create a <code>for</code> loop that loops through the length of the <strong>eventDates</strong> array. Use <code>i</code> as the counter variable.</p>
    <p>Within the <code>for</code> loop insert the following commands in a command block:</p>
    <ul>
        <li>Declare a variable named <strong>eventDate</strong> containing a <code>Date</code> object with the date stored in the <code>i</code> entry in the <strong>eventDates</strong>array.</li>
        <li>Declare a variable named <strong>eventDay</strong> that stores the text of the <strong>eventDate</strong> date using the <code>toDateString()</code> method.</li>
        <li>Declare a variable named <strong>eventTime</strong> that stores the text of the <strong>eventDate</strong> time using the <code>toLocaleTimeString()</code>method.</li>
        <li>Insert an <code>if</code> statement that has a conditional expression that tests whether <strong>thisDay</strong> is <code>&le;</code> <strong>eventDate</strong> and <strong>eventDate</strong> <code>&le;</code><strong>endDate</strong>. If so, the event falls within the two-week window that Lewis has requested and the script should add the following HTML code text to the value of the tableHTML variable.</li>
    </ul>
    <pre class="cmh-pre light"><code class="cmh" data-language="html"><span><span class="mtk1">&lt;</span><span class="mtk15">tr</span><span class="mtk1">&gt;</span></span><br /><span><span class="mtk1">&lt;</span><span class="mtk15">td</span><span class="mtk1">&gt;&nbsp;&nbsp;eventDay&nbsp;&nbsp;@&nbsp;&nbsp;eventTime&nbsp;&nbsp;&lt;/</span><span class="mtk15">td</span><span class="mtk1">&gt;</span></span><br /><span><span class="mtk1">&lt;</span><span class="mtk15">td</span><span class="mtk1">&gt;&nbsp;&nbsp;description&nbsp;&nbsp;&lt;/</span><span class="mtk15">td</span><span class="mtk1">&gt;&nbsp;</span></span><br /><span><span class="mtk1">&lt;</span><span class="mtk15">td</span><span class="mtk1">&gt;&nbsp;&nbsp;price&nbsp;&nbsp;&lt;/</span><span class="mtk15">td</span><span class="mtk1">&gt;</span></span><br /><span><span class="mtk1">&lt;/</span><span class="mtk15">tr</span><span class="mtk1">&gt;&nbsp;</span></span><br /></code></pre>
    <ul>
        <li>Where <strong>eventDay</strong> is the value of the <strong>eventDay</strong> variable, <strong>eventTime</strong> is the value of the <strong>eventTime</strong> variable, description is the <code>i</code> entry in the <strong>eventDescriptions</strong> array, and price is the <code>i</code> entry in the <strong>eventPrices</strong> array.</li>
    </ul>
    <h3>HTML Table Code</h3>
    <p>After the <code>for</code> loop, add the text of the HTML code <code>&lt;/table&gt;</code> to the value of the <strong>tableHTML</strong> variable.</p>
    <p>Insert the value of the <strong>tableHTML</strong> variable into the inner HTML of the <code>page</code> element with the ID <strong>eventList</strong>.</p>
    <p>
        <span>Verify that the page shows theater events over a two-week period starting with </span><strong>October 1, 2021</strong>
        <span>&nbsp;and concluding with </span><strong>October 14, 2021</strong>
        <span>.</span>
    </p>
</div>
