# t7-code-2
<div class="custom-markdown steps-contents">
    <div class="step-block-outer step-block--not-last">
        <div class="step-block-header" role="heading" aria-level="2">
            <div class="custom-markdown steps-contents">
                <div class="step-block-outer step-block--not-last">
                    <div class="step-block-header" role="heading" aria-level="2">
                        <div class="custom-markdown steps-contents">
                            <h2>Summary</h2>
                            <p>You&rsquo;ve been asked to create a survey web form for use in a seminar conference website. Some of the questions from the form are shown in <em>Figure 7&ndash;60</em>. Use your knowledge of HTML form elements to create the form elements and labels.</p>
                            <p>&nbsp;</p>
                            <figure>
                                <a class="markdown-image-link" title="Open image in a new tab" href="https://cdn.filestackcontent.com/5Un8gkUT0ykzb7N9PBfW" target="_blank" rel="noopener">
                                    <img src="https://cdn.filestackcontent.com/5Un8gkUT0ykzb7N9PBfW" alt="A webpage displays 5 survey questions. Options for the first three questions are assigned with radio option buttons. The fourth question is assigned with a range slider and the last question is assigned with a text area. " />
                                </a>
                            </figure>
                            <sup><em>Figure 7-60</em></sup>
                            <p>&nbsp;</p>
                            <p>Do the following:</p>
                        </div>
                        <div class="step-block-outer step-block--not-last">
                            <div class="step-block-header" role="heading" aria-level="2">Tasks</div>
                            <div class="step-block-header" role="heading" aria-level="2">
                                <br />
                                <span>Open the file </span><em>code7-2.html</em>
                                <span> and in the comment section enter your </span><strong>name</strong>
                                <span> (First + Last) and the </span><strong>date&nbsp;</strong>
                                <span>(MM/DD/YYYY) into the </span><code>Author:</code>
                                <span>and </span><code>Date:</code>
                                <span> fields of the file.</span>
                            </div>
                            <div class="step-block-header" role="heading" aria-level="2">
                                <br />
                                <span>Open the </span><em>code7-2.html</em>
                                <span> file and within the </span><code>head</code>
                                <span> section insert a </span><code>link</code>
                                <span> element linking the page to the </span><em>code7-2_forms.css</em>
                                <span> style sheet.</span>
                            </div>
                            <div class="step-block-header" role="heading" aria-level="2">
                                <br />
                                <span>Immediately after the </span><code>h1</code>
                                <span> tag create the form by enclosing the list of questions within opening and closing </span><code>&lt;form&gt;</code>
                                <span> tags. Give the form the </span><code>action</code> <em>submit-survey.php</em>
                                <span> using the </span><strong>post&nbsp;</strong>
                                <span>method.</span>
                            </div>
                            <div class="step-block-header" role="heading" aria-level="2">
                                <br />
                                <p>The survey questions are marked as an ordered list. The first three questions include a nested list of options. For the first question do the following:</p>
                                <ol>
                                    <li>Mark the text from <strong>Very Satisfied</strong> to <strong>Very Dissatisfied&nbsp;</strong>as form labels.</li>
                                    <li>Before each <code>label</code> insert a radio button belonging to the <code>q1</code> field with default values of <strong>a</strong> through <strong>d</strong>. Assign the radio button controls the ids<code>q1a</code> through <code>q1d</code>.</li>
                                    <li>Use the <code>for</code> attribute to associate each <code>label</code> with its radio button control.</li>
                                </ol>
                                <p>
                                    <span>Repeat the previous task ("Create the first survey question") for questions 2 and 3, naming the fields for those radio buttons </span><code>q2</code>
                                    <span>and </span><code>q3</code>
                                    <span> respectively and assigning the radio button controls the ids </span><code>q2a</code>
                                    <span> through </span><code>q2d</code>
                                    <span> for the second question and </span><code>q3a</code>
                                    <span> through </span><code>q3d</code>
                                    <span> for the third question.</span>
                                </p>
                                <p>
                                    <span>Within the <code>div</code> element with the id <code>newRow</code> insert a range slider that ranges from <strong>1</strong> to <strong>10</strong> in steps of <strong>1</strong>, with a default value of <strong>5</strong>. Insert the text <strong>very unlikely</strong> before the range slider and the text <strong>very likely</strong> after the range slider. Assign the range slider the field name <code>q4</code>.</span>
                                </p>
                                <p>Mark the text <strong>Provide any suggestions for the next conference</strong> as a form <code>label</code> and use the <code>for</code> attribute to attach the <code>label</code> to the input control with the id <code>q5text</code>.</p>
                                <p>Below the label, insert a <code>textarea</code> control with the id <code>q5text</code> and the field name <code>q5</code>. Add the placeholder text <strong>enter your suggestions here</strong>.</p>
                                <p>
                                    <span>Verify that the layout of form matches that shown in </span><em>Figure 7&ndash;60</em>
                                    <span>.</span>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
