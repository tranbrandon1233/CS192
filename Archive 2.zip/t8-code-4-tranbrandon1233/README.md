# t8-code-4
<div class="custom-markdown steps-contents">
    <div class="step-block-outer step-block--not-last">
        <div class="step-block-header" role="heading" aria-level="2">
            <div class="custom-markdown steps-contents">
                <div class="step-block-outer step-block--not-last">
                    <div class="step-block-header" role="heading" aria-level="2">
                        <div class="step-block-outer step-block--not-last">
                            <div class="step-block-header" role="heading" aria-level="2">
                                <h2>Summary</h2>
                                <p>You can use transitions and animations in web forms to draw your eyes to particular form elements or to highlight invalid form data. You&rsquo;ve been given a website that uses a transition effect to highlight invalid credit card values; however, the transition effects and animation are not working. You will edit the style sheet of the page shown in <em>Figure 8&ndash;62</em> to fix the problem.</p>
                                <div class="custom-markdown steps-contents">
                                    <video width="480" height="320" controls="controls">
                                        <source class="embed-responsive-item" src="https://cdn.filestackcontent.com/IftoEfXfTcegbwLRO4at" type="video/mp4" />
                                        Your browser does not support the video tag.
                                    </video>
                                    <p>&nbsp;</p>
                                    <p><sup><em>Figure 8-62</em></sup></p>
                                    <p>Do the following:</p>
                                </div>
                                <div class="step-block-outer step-block--not-last">
                                    <div class="step-block-header" role="heading" aria-level="2">Tasks</div>
                                    <div class="step-block-header" role="heading" aria-level="2">
                                        <br />
                                        <span>Open the file </span><em>code8-4.html</em>
                                        <span> and </span><em>code8-4_debug.css</em>
                                        <span> and in the comment section enter your </span><strong>name</strong>
                                        <span> (First + Last) and the </span><strong>date</strong>
                                        <span>(MM/DD/YYYY) into the </span><code>Author:</code>
                                        <span>and </span><code>Date:</code>
                                        <span> fields of each file.</span>
                                    </div>
                                    <div class="step-block-header" role="heading" aria-level="2">
                                        <br />
                                        <span>Open the </span><em>code8-4.html</em>
                                        <span> file and within the </span><code>head</code>
                                        <span> section insert a </span><code>link</code>
                                        <span> element that links the page to the </span><em>code8-4_debug.css</em>
                                        <span> style sheet file.</span>
                                    </div>
                                    <div class="step-block-header" role="heading" aria-level="2">
                                        <br />
                                        <span>Open the </span><em>code8-4.html</em>
                                        <span> file. When the page opens, the </span><code>h1</code>
                                        <span> heading should slide into the page from the left and the form should drop in from the top. Neither is happening. Open the </span><em>code8-4_debug.css</em>
                                        <span> file and study the code that applies the animation effect to the </span><code>form#payment</code>
                                        <span>object and the </span><code>h1</code>
                                        <span> element. Fix any mistakes in the code that you find and verify that the opening of the page runs the drop-in and slight-right animations.</span>
                                    </div>
                                    <div class="step-block-header" role="heading" aria-level="2">
                                        <br />
                                        <span>When the </span><strong>Credit Card Number</strong>
                                        <span>box and the </span><strong>CSC</strong>
                                        <span> box receive the focus, a transition effect should appear that slowly adds a glowing brown shadow around the boxes. The glowing brown shadow appears but without a transition effect. Return to the </span><em>code8-4_debug.css</em>
                                        <span> file and study the code that applies a transition effect to both the </span><code>input#cardBox</code>
                                        <span> and </span><code>input#CSC</code>
                                        <span>objects, and the </span><code>input#csc:invalid</code>
                                        <span> style. Correct any mistakes you find in the code. Verify that when the </span><strong>Credit Card Number</strong>
                                        <span> and </span><strong>CSC&nbsp;</strong>
                                        <span>boxes receive the focus a transition effect appears that adds the glowing brown shadow to the boxes.
                                            <br />
                                            <br />
                                        </span>
                                    </div>
                                    <div class="step-block-header" role="heading" aria-level="2">
                                        <span>A </span><strong>3</strong>
                                        <span>-digit number should be entered in the </span><strong>CSC</strong>
                                        <span> box. If something other than a </span><strong>3</strong>
                                        <span> digit number is entered, the box should wiggle back and forth to indicate invalid data. That is not currently happening. Open the </span><em>code8-4_debug.css</em>
                                        <span> file. Study the code that applies the transition effect to the </span><code>input#csc</code>
                                        <span> object when invalid data is entered. Correct any mistakes in the code that you find. Verify that when you enter invalid data in the </span><strong>CSC</strong>
                                        <span> box, the box wiggles back and forth to indicate that the data is not valid.</span>
                                    </div>
                                    <div class="step-block-header" role="heading" aria-level="2">
                                        <span>
                                            <br />Open the website in the browser preview. Verify that when you enter invalid data in the CSC box, the box wiggles back and forth to indicate that the data is not valid.
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
