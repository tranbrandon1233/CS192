# t8-code-2
<div class="custom-markdown steps-contents">
    <div class="step-block-outer step-block--not-last">
        <div class="step-block-header" role="heading" aria-level="2">
            <div class="custom-markdown steps-contents">
                <div class="step-block-outer step-block--not-last">
                    <div class="step-block-header" role="heading" aria-level="2">
                        <div class="custom-markdown steps-contents">
                            <div class="custom-markdown steps-contents">
                                <h2>Summary</h2>
                                <p>Transitions with the hover effect can be used in image galleries to display large versions of thumbnail images. <em>Figure 8&ndash;60</em> shows an image gallery of Renaissance sketches that are enlarged in response to the hover event. Use your knowledge of CSS transitions to complete this web page.</p>
                                <p>&nbsp;</p>
                                <figure>
                                    <a class="markdown-image-link" title="Open image in a new tab" href="https://cdn.filestackcontent.com/SHNuiAbYSSuwyMCIX1oB" target="_blank" rel="noopener">
                                        <img src="https://cdn.filestackcontent.com/SHNuiAbYSSuwyMCIX1oB" alt="A web page of image gallery. The page titled Artist Sketchpad consists of five Renaissance sketches. Four sketches are displayed on the left of the page in thumbnail size. The fifth sketch is enlarged and displayed on the right with a text below the sketch, &ldquo;Head of a Maid &ndash; Pontomo&rdquo;." />
                                    </a>
                                </figure>
                                <p>&nbsp;</p>
                                <p><sup><em>Figure 8-60</em></sup></p>
                                <p>Do the following:</p>
                            </div>
                            <div class="step-block-outer step-block--not-last">
                                <div class="step-block-header" role="heading" aria-level="2">Tasks</div>
                                <div class="step-block-header" role="heading" aria-level="2">
                                    <span>Open the file </span><em>code8-2.html</em>
                                    <span> and </span><em>code8-2_trans.css</em>
                                    <span> and in the comment section enter your </span><strong>name</strong>
                                    <span> (First + Last) and the </span><strong>date</strong>
                                    <span>(MM/DD/YYYY) into the </span><code>Author:</code>
                                    <span>and </span><code>Date:</code>
                                    <span> fields of each file.</span>
                                </div>
                                <div class="step-block-header" role="heading" aria-level="2">
                                    <span>
                                        <br />Go to the <em>code8-2.html</em> file and within the <code>head</code>section insert a <code>link</code> element linking the page to the <em>code8-2_trans.css</em> file. Study the contents of the file.
                                    </span>
                                </div>
                                <div class="step-block-header" role="heading" aria-level="2">
                                    <span>
                                        <span>
                                            <br />
                                        </span>
                                    </span>
                                    <p>Go to the <em>code8-2_trans.css</em> file and at the bottom of the file create a style rule for the <code>figure</code>element during the hover event that:</p>
                                    <ol>
                                        <li>Sets the <code>width</code> to <strong>400</strong> pixels,</li>
                                        <li>Sets the <code>z-index</code> value to <strong>2</strong>, and</li>
                                        <li>Applies the transition for the change in the <code>width</code> property over a <strong>2</strong>-second interval.</li>
                                    </ol>
                                    <p>Create a style rule for <code>img</code>elements within hovered figure elements that:</p>
                                    <ol>
                                        <li>Sets the <code>width</code> to <strong>100%</strong></li>
                                        <li>Applies the <code>drop-shadow(offset-x offset-y blur-radius color)</code>and <code>grayscale(0)</code> filter functions,</li>
                                        <li>Sets the drop shadow offset to <strong>10</strong> pixels in the horizontal and vertical directions and the blur radius to <strong>20</strong> pixels,</li>
                                        <li>Sets the color value to <strong>black</strong>, and</li>
                                        <li>Applies a transition to the change in the filter property over a <strong>2</strong>-second interval.</li>
                                    </ol>
                                    <p>
                                        <span>Create a style rule for </span><code>figcaption</code>
                                        <span> elements within the hovered </span><code>figure</code>
                                        <span> element, that sets the font size to </span><strong>1.2em</strong>
                                        <span>, and applies the change in font size over a </span><strong>2</strong>
                                        <span>-second transition.</span>
                                    </p>
                                    <p>
                                        <span>Create a style rule for the <code>#fig1</code> through <code>#fig6</code> elements which are hovered, that rotates the elements to <strong>0</strong> degrees using the transform property, and applies a <strong>2</strong>-second transition to all properties of those figures.</span>
                                    </p>
                                    <p>
                                        <span>Open the website in the browser preview and verify that when you hover your mouse pointer over any of the six images, the figures are rotated to 0 degrees, increased in size, moved on top of the other figure images, and the figure captions appear below the figures.</span>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
