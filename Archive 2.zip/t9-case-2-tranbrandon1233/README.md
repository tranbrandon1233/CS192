# t9-case-2
Austen Vynes
<h2>Summary</h2>
<p><strong>Austen Vynes</strong> - Emelia Dawes shares her passion for the works of Jane Austen by managing a website named Austen Vynes dedicated to the writer and her works. Emelia is revising the layout and design of her website and would like your assistance in redesigning the front page. She wants the front page to display a random Jane Austen quote every time the page is loaded by the browser. Emelia asks you to write a JavaScript program to supply a randomly selected quote. A preview of the page is shown in <strong>Figure 9&ndash;46</strong>.</p>
<p>&nbsp;</p>
<figure>
    <a class="markdown-image-link" title="Open image in a new tab" href="https://cdn.filestackcontent.com/xs5BStQzSkm7RqPpJKPZ" target="_blank" rel="noopener">
        <img src="https://cdn.filestackcontent.com/xs5BStQzSkm7RqPpJKPZ" alt="A homepage preview of &ldquo;Austen Vynes&rdquo; website displays a random quote. " />
    </a>
</figure>
<p>&nbsp;</p>
<p><sup><em>Figure 9-46</em></sup></p>
<h2>Document Setup</h2>
<p>Open the <em>ja_vynes.html</em> and <em>ja_quote.js</em> files and enter your <strong>name</strong> and the <strong>date</strong> in the comment section of each file. Next, go to the <em>ja_vynes.html</em> file and directly above the closing <code>&lt;/head&gt;</code>tag, insert a <code>script</code> element that links the page to the <em>ja_quote.js</em> file. Defer the loading of the script file until the rest of the page is loaded by the browser. Study the contents of the file.</p>
<h2>Complete the JavaScript File</h2>
<p>Open the <em>ja_quote.js</em> file and at the top of the file, insert a statement indicating that the code will be handled by the browser assuming strict usage. Directly below the comment section, insert a function named <code>randomInt</code> that will be used to generate a random integer. Specify two parameters for the function named lowest and size. The lowest parameter will specify the lowest possible value for the random integer and the size parameter will set the number of integers to be generated. Use those two parameter values and the <code>Math.floor()</code> and <code>Math.random()</code> methods to return a random integer within the specified range.</p>
<p>Above the <code>randomInt()</code> function insert a command to call the function, generating a random integer from <strong>0</strong> to <strong>9</strong>.</p>
<blockquote class="info">
    <p>Remember that the size of this interval is <strong>10</strong> because it includes <strong>0&nbsp;</strong>in its range.</p>
</blockquote>
<p>Store the result from the function in the <code>randomQ</code> variable. Create a variable named <code>quoteElem</code> that references the first element in the document that has the quote tag <strong>name</strong>.</p>
<p>Call the <code>getQuote()</code> function using the <code>randomQ</code> variable as the parameter value to generate a random Jane Austen quote. Display the text of the quote as the inner HTML code of the <code>quoteElem</code> variable. Add appropriate comments to your code to document your work.</p>
<p>Open the <em>ja_vynes.html</em> file in the browser preview and verify that a random Jane Austen quote appears at the top of the page. Reload the page several times and verify that with each reloading, a different Austen quote appears on the page.</p>
<p>Reload the <em>bc_union.html</em> file in the browser preview to show the date and the events for the current day of the week.</p>
