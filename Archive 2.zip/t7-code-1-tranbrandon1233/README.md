# t7-code-1
<div class="custom-markdown steps-contents">
    <div class="step-block-outer step-block--not-last">
        <div class="step-block-header" role="heading" aria-level="2">
            <div class="step-block-outer step-block--not-last">
                <div class="step-block-header" role="heading" aria-level="2">
                    <div class="custom-markdown steps-contents">
                        <h2>Summary</h2>
                        <p>Use your knowledge of HTML form elements to create the user account login form shown in <em>Figure 7&ndash;59</em>.</p>
                        <p>&nbsp;</p>
                        <figure>
                            <a class="markdown-image-link" title="Open image in a new tab" href="https://cdn.filestackcontent.com/bQPcHk90SYCJMBpTwVE5" target="_blank" rel="noopener">
                                <img src="https://cdn.filestackcontent.com/bQPcHk90SYCJMBpTwVE5" alt="A screenshot of &ldquo;Enter User Account&rdquo; dialog box. The dialog box displays Enter Account Information section listing the following options below: Account type with the dropdown box, Username, and Password. A Login button is displayed at the bottom of the dialog box. " />
                            </a>
                        </figure>
                        <sup><em>Figure 7-59</em></sup>
                        <p>&nbsp;</p>
                        <p>Do the following:</p>
                    </div>
                    <div class="step-block-outer step-block--not-last">
                        <div class="step-block-header" role="heading" aria-level="2">Tasks</div>
                        <div class="step-block-header" role="heading" aria-level="2">
                            <br />
                            <span>Open the file </span><em>code7-1.html</em>
                            <span> and in the comment section enter your </span><strong>name</strong>
                            <span> (First + Last) and the </span><strong>date&nbsp;</strong>
                            <span>(MM/DD/YYYY) into the </span><code>Author:</code>
                            <span>and </span><code>Date:</code>
                            <span> fields of the file.</span>
                        </div>
                        <div class="step-block-header" role="heading" aria-level="2">
                            <br />
                            <span>Go to the </span><em>code7-1.html</em>
                            <span> file and within the </span><code>head</code>
                            <span> section insert a </span><code>link</code>
                            <span> element linking the page to the </span><em>code7-1_forms.css</em>
                            <span> style sheet. Also insert a </span><code>script</code>
                            <span> element that opens the </span><em>formsubmit.js&nbsp;</em>
                            <span>JavaScript file for handling the form submissions.</span>
                        </div>
                        <div class="step-block-header" role="heading" aria-level="2">
                            <span>
                                <br />Within the <code>body</code> of the web page insert a <code>form</code> element with the value of the <code>action</code> attribute set to <em>login-script.php</em> and the method value set to <strong>post</strong>.
                            </span>
                        </div>
                        <div class="step-block-header" role="heading" aria-level="2">
                            <span>
                                <br />Within the web form create a field set with the id <code>login</code>. Within the field set insert a legend with the text <strong>Enter Account Information</strong>.
                            </span>
                        </div>
                        <div class="step-block-header" role="heading" aria-level="2">
                            <span>
                                <br />Within the field set insert a <code>label</code> containing the text <strong>Account Type</strong>. After the <code>label</code> add a selection list with the id <code>acctype</code> and the field name <strong>accounttype</strong>. Set the value of the size attribute of the selection list to <strong>3</strong> and add the following three options: <strong>administrator</strong>, <strong>member</strong>, and <strong>guest</strong>. Set the value of the three options to <strong>type1</strong>, <strong>type2</strong>, and <strong>type3</strong> respectively. Link the <code>label</code> to the selection list using the <code>for</code> attribute with a value of <strong>acctype</strong>.
                            </span>
                        </div>
                        <div class="step-block-header" role="heading" aria-level="2">
                            <span>
                                <br />Add a <code>label</code> to the field set containing the text <strong>Username&nbsp;</strong>followed by a text input box with the id <code>username</code> and the field name <strong>user</strong>. Use the <code>for</code> attribute to link the <code>label</code> to the input box control.
                            </span>
                        </div>
                        <div class="step-block-header" role="heading" aria-level="2">
                            <span>
                                <br />Add another <code>label</code> to the field set containing the text <strong>Password&nbsp;</strong>followed by a password input box with the id <code>password</code> and the field name <strong>pwd</strong>. Use the <code>for</code> attribute to link the <code>label</code> to the password input box.
                            </span>
                        </div>
                        <div class="step-block-header" role="heading" aria-level="2">
                            <span>
                                <br />Below the field set insert a submit button displaying the text <strong>Login</strong>.
                            </span>
                        </div>
                        <div class="step-block-header" role="heading" aria-level="2">
                            <span>
                                <br />Verify that the layout of the table resembles that shown in <em>Figure 7&ndash;59</em> and that when you click each label, the control associated with that label becomes selected. Further verify that clicking the Login button submits the form for processing.
                            </span>
                        </div>
                        <div class="step-block-header" role="heading" aria-level="2">
                            <span>&nbsp;</span>
                        </div>
                    </div>
                </div>
            </div>
