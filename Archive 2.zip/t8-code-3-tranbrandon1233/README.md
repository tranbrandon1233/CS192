# t8-code-3
<div class="custom-markdown steps-contents">
    <div class="step-block-outer step-block--not-last">
        <div class="step-block-header" role="heading" aria-level="2">
            <div class="custom-markdown steps-contents">
                <div class="step-block-outer step-block--not-last">
                    <div class="step-block-header" role="heading" aria-level="2">
                        <div class="step-block-outer step-block--not-last">
                            <div class="step-block-header" role="heading" aria-level="2">
                                <div class="custom-markdown steps-contents">
                                    <div class="custom-markdown steps-contents">
                                        <h2>Summary</h2>
                                        <p>Animation can be used with 3D objects to create the illusion of objects moving and spinning in 3D space. <em>Figure 8&ndash;61</em> shows the opening page of the Artist Sketchbook web page in which six drawings from Renaissance masters have been combined in a 3D cube. You will use CSS animation to spin the cube, showing all faces of the cube during the animation.</p>
                                        <div>
                                            <video width="480" height="320" controls="controls">
                                                <source class="embed-responsive-item" src="https://cdn.filestackcontent.com/svTBMlIRVez7eMZzJWdA" type="video/mp4" />
                                                Your browser does not support the video tag.
                                            </video>
                                        </div>
                                        <p><sup><em>Figure 8-61</em></sup></p>
                                        <p>Do the following:</p>
                                    </div>
                                    <div class="step-block-outer step-block--not-last">
                                        <div class="step-block-header" role="heading" aria-level="2">Tasks</div>
                                        <div class="step-block-header" role="heading" aria-level="2">
                                            <br />
                                            <span>Open the file </span><em>code8-3.html</em>
                                            <span> and </span><em>code8-3_anim.css</em>
                                            <span> and in the comment section enter your </span><strong>name</strong>
                                            <span> (First + Last) and the </span><strong>date</strong>
                                            <span>(MM/DD/YYYY) into the </span><code>Author:</code>
                                            <span>and </span><code>Date:</code>
                                            <span> fields of each file.</span>
                                        </div>
                                        <div class="step-block-header" role="heading" aria-level="2">
                                            <br />
                                            <span>Open the </span><em>code8-3.html</em>
                                            <span> file and within the </span><code>head</code>
                                            <span> section insert a </span><code>link</code>
                                            <span> element that links the page to the </span><em>code8-3_anim.css</em>
                                            <span> style sheet file. Take some time to review the contents of the file.</span>
                                        </div>
                                        <div class="step-block-header" role="heading" aria-level="2">
                                            <br />
                                            <p>Open the <em>code8-3_anim.css</em> file. Several keyframe animations have already been created for you. Add a keyframe animation named <code>spinCube</code> that contains the following frames:</p>
                                            <ol>
                                                <li>At <strong>0%</strong> apply the transform property with the <code>rotateX()</code>function set to <strong>24deg</strong> and the <code>rotateY()</code> function set to <strong>40deg</strong>.</li>
                                                <li>At <strong>50%</strong> change the value of the <code>rotateX()</code> function to <strong>204deg</strong> and the <code>rotateY()</code>function to <strong>220deg</strong></li>
                                                <li>At <strong>100%</strong>, change the value of the <code>rotateX()</code> function to <strong>384</strong> and the <code>rotateY()</code>function to <strong>400deg</strong>.</li>
                                            </ol>
                                            <p>
                                                <span>When the page is initially opened you want it to display animation of the six faces of the cube being assembled. Create a style rule that applies the </span><code>moveFront</code>
                                                <span>keyframe animation to the </span><code>#faceFront</code>
                                                <span> object. Set the duration of the animation to </span><strong>3</strong>
                                                <span>seconds and set the </span><code>animation- fill-mode</code>
                                                <span>property to </span><strong>forwards</strong>
                                                <span>.</span>
                                            </p>
                                            <p>
                                                <span>Repeat the previous step for the <code>#faceBack</code>, <code>#faceBottom</code>, <code>#faceLeft</code>, <code>#faceTop</code>, and <code>#faceRight</code> objects using the <code>moveBack</code>, <code>moveBottom</code>, <code>moveLeft</code>, <code>moveTop</code>, and <code>moveRight</code> animations.</span>
                                            </p>
                                            <p>
                                                <span>After the cube is assembled you want it to rotate. Create a style rule that applies the <code>spinCube</code>animation to the <code>#cube</code> object, running the animation over a <strong>3</strong>second duration after a delay of <strong>3</strong>seconds. Use the linear timing function and have the animation loop without ending.</span>
                                            </p>
                                            <p>
                                                <span>Open the website in the browser preview. Verify that in the first 3 seconds the cube is assembled by moving the six faces into position and that after 3 seconds, the cube begins spinning to show all the faces of the cube.</span>
                                            </p>
                                        </div>
                                    </div>
                                </div>
