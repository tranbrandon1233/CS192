# t7-code-4
<div class="custom-markdown steps-contents">
    <div class="step-block-outer step-block--not-last">
        <div class="step-block-header" role="heading" aria-level="2">
            <div class="custom-markdown steps-contents">
                <div class="step-block-outer step-block--not-last">
                    <div class="step-block-header" role="heading" aria-level="2">
                        <div class="step-block-outer step-block--not-last">
                            <div class="step-block-header" role="heading" aria-level="2">
                                <h2>Summary</h2>
                                <p>You have been given the HTML code for a proposed web form shown in <em>Figure 7&ndash;62</em>. Unfortunately, there are several syntax errors in the HTML code. You&rsquo;ve been asked to find and correct all errors so that the page passes validation.</p>
                                <p>&nbsp;</p>
                                <figure>
                                    <a class="markdown-image-link" title="Open image in a new tab" href="https://cdn.filestackcontent.com/as3BHcGS5WYDVkf6XxE6" target="_blank" rel="noopener">
                                        <img src="https://cdn.filestackcontent.com/as3BHcGS5WYDVkf6XxE6" alt="A screenshot of a &ldquo;Contact Information&rdquo; dialog box. The dialog box lists the following fields: First name field, Last name field, Student I D field, Dropdown for selecting year, and Residence hall field. A Submit button is displayed at the left bottom of the dialog box. " />
                                    </a>
                                </figure>
                                <p><sup><em>Figure 7-62</em></sup></p>
                                <p>&nbsp;</p>
                                <p>Do the following:</p>
                                <p>
                                    <span>Open the file </span><em>code7-4.html</em>
                                    <span> and in the comment section enter your </span><strong>name</strong>
                                    <span> (First + Last) and the </span><strong>date&nbsp;</strong>
                                    <span>(MM/DD/YYYY) into the </span><code>Author:</code>
                                    <span> and </span><code>Date:</code>
                                    <span> fields.</span>
                                </p>
                                <p>
                                    <span>Open <em>code7-4.html</em> file and within the <code>head</code> section insert a <code>link</code> element linking the page to the <em>code7-4_forms.css</em>.</span>
                                </p>
                                <p>Within the <em>code7-4.html</em> file locate and fix the errors in the page so that the file passes validation with no errors or warnings. Note that some of the same errors are repeated multiple times throughout the HTML code.</p>
                                <blockquote class="info">
                                    <p>The <code>for</code> attribute for some of the labels is incorrect! Make sure attribute matches the corresponding <code>input</code> or <code>select</code> id.</p>
                                </blockquote>
                                <p>
                                    <span>Open the website in the browser preview to confirm that it resembles the page shown in </span><em>Figure 7&ndash;62</em>
                                    <span>.</span>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
