# t7-code-3
<div class="custom-markdown steps-contents">
    <div class="step-block-outer step-block--not-last">
        <div class="step-block-header" role="heading" aria-level="2">
            <div class="custom-markdown steps-contents">
                <div class="step-block-outer step-block--not-last">
                    <div class="step-block-header" role="heading" aria-level="2">
                        <div class="step-block-outer step-block--not-last">
                            <div class="step-block-header" role="heading" aria-level="2">
                                <div class="custom-markdown steps-contents">
                                    <h2>Summary</h2>
                                    <p>You&rsquo;ve been asked to complete a web form containing credit card payment information. Part of your task will be to include validation test to ensure that required data is entered correctly into the form. <em>Figure 7&ndash;61</em> shows the completed form.</p>
                                    <p>&nbsp;</p>
                                    <figure>
                                        <a class="markdown-image-link" title="Open image in a new tab" href="https://cdn.filestackcontent.com/54k4AtSKWywLzZFC80Xw" target="_blank" rel="noopener">
                                            <img src="https://cdn.filestackcontent.com/54k4AtSKWywLzZFC80Xw" alt="A screenshot of a &ldquo;Payment Information&rdquo; dialog box is displayed. The dialog box lists the following fields: Dropdown box for selecting credit card, card name field, card number field, dropdown box for selecting card month, dropdown box for selecting card year, and C S C number field. A Submit Payment button is displayed at the bottom of the dialog box. The card number field is shown highlighted in red." />
                                        </a>
                                    </figure>
                                    <sup><em>Figure 7-61</em></sup>
                                    <p>&nbsp;</p>
                                    <p>Do the following:</p>
                                </div>
                                <div class="step-block-outer step-block--not-last">
                                    <div class="step-block-header" role="heading" aria-level="2">Tasks</div>
                                    <div class="step-block-header" role="heading" aria-level="2">
                                        <span>Open the files </span><em>code7-3.html</em>
                                        <span> and </span><em>code7-3_valid.css</em>
                                        <span> and in the comment section enter your </span><strong>name</strong>
                                        <span> (First + Last) and the </span><strong>date</strong>
                                        <span>(MM/DD/YYYY) into the </span><code>Author:</code>
                                        <span>and </span><code>Date:</code>
                                        <span> fields of each file.</span>
                                    </div>
                                    <div class="step-block-header" role="heading" aria-level="2">
                                        <span>
                                            <br />Go to the <em>code7-3.html</em> file and within the <code>head</code> section insert <code>link</code> elements linking the page to the <em>code7-3_forms.css</em> and <em>code7-3_valid.css</em> files. Insert a <code>script</code> element to load the <em>formsubmit.js</em> JavaScript file.
                                        </span>
                                    </div>
                                    <div class="step-block-header" role="heading" aria-level="2">
                                        <span>
                                            <span>
                                                <br />
                                            </span>
                                        </span>
                                        <p>Within the <code>creditcard</code> selection list add the following options and values: <strong>Credit Card Type</strong> (leave the value as an empty text string), <strong>American Express (value="amex")</strong>, <strong>Discover (value="disc")</strong>, <strong>MasterCard (value="master")</strong>, and <strong>Visa (value="visa")</strong>.</p>
                                        <p>Make the selection list and <code>cardname</code> field required.</p>
                                        <p>
                                            <span>Make the </span><code>cardnumber</code>
                                            <span> field required and add the regular expression pattern indicated in the comment section of the HTML file to help ensure that a valid card number is used.</span>
                                        </p>
                                        <p>
                                            <span>Within the <code>cardmonth</code> selection list add options for each month starting with the text <strong>Month</strong> and a value of a blank text string followed by the option text <strong>January (01)</strong> through <strong>December (12)</strong> with the corresponding values <strong>01</strong> through <strong>12</strong>. Make the selection list required.</span>
                                        </p>
                                        <p>
                                            <span>Within the <code>cardyear</code> selection list add options for each year starting with the text <strong>Year</strong> and a value of a blank text string followed by the option text <strong>2020&nbsp;</strong>through <strong>2024</strong> with the corresponding values <strong>2020&nbsp;</strong>through <strong>2024</strong>.</span>
                                        </p>
                                        <p>
                                            <span>Make the <code>cardcsc</code> field required with a maximum character length of <strong>3</strong> characters following the regular expression pattern: <code>^\d{3}$</code>&nbsp;</span>
                                        </p>
                                        <p>Open the <em>code7-3_valid.css</em> file and add the following style rules to the file:</p>
                                        <ol>
                                            <li>Display any input or select element that has the focus with a <strong>yellow</strong> background color.</li>
                                            <li>Display any input element with invalid data in a <strong>red</strong> font, surrounded by a <strong>red</strong> border, and <strong>red</strong> box shadows that are offset <strong>0</strong> pixels horizontally and vertically with a shadow blur of <strong>5</strong> pixels.</li>
                                        </ol>
                                        <p>
                                            <span>View the page the browser preview to verify the contents match than shown in </span><em>Figure 7&ndash;61</em>
                                            <span>. Test your payment form by trying to submit the form data with missing values or with incorrect values. Attempt to submit the form using the invalid credit card number 412345678901 and then with the valid card number 4123456789012.</span>
                                        </p>
