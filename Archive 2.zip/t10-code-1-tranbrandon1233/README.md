<div class="custom-markdown steps-contents">
    <h2>Summary</h2>
    <p>You are working on a JavaScript app to create a gallery of slide images. To create the gallery, you will apply a for loop that loops through an array of images and captions to create the HTML code for the figure elements. <em>Figure 10&ndash;34</em> shows a preview of the gallery.</p>
    <p>&nbsp;</p>
    <figure>
        <a class="markdown-image-link" title="Open image in a new tab" href="https://cdn.filestackcontent.com/iElCnBbQUCquNv7iq0LX" target="_blank" rel="noopener">
            <img src="https://cdn.filestackcontent.com/iElCnBbQUCquNv7iq0LX" alt="A page titled, International Space Station Images displays fourteen images with their names as follows: International Space Station fourth expansion [2009], Assembling the International Space Station [1998], The Atlantis docks with the I S S [2001], The Atlantis approaches the I S S [2000], The Atlantis approaches the I S S [2000], International Space Station over Earth [2002], The International Space Station first expansion [2002], Hurricane Ivan from the I S S [2008], The Soyuz spacecraft approaches the I S S [2005], The International Space Station from above [2006], Maneuvering in space with the Canadarm 2 [2006], The International Space Station second expansion [2006], The International Space Station third expansion [2007], The I S S over the Ionian Sea [2007].  " />
        </a>
    </figure>
    <p>&nbsp;</p>
    <p><sup><em>Figure 10-34</em></sup></p>
    <p>Do the following:</p>
</div>
<div class="step-block-outer step-block--not-last">
    <div class="step-block-header" role="heading" aria-level="2"><strong>Tasks</strong></div>
    <div class="step-block-header" role="heading" aria-level="2">
        <span>Open the files </span><em>code10-1.html</em>
        <span> and </span><em>gallery10-1.js</em>
        <span> and in the comment section enter your </span><strong>name</strong>
        <span> (First + Last) and the </span><strong>date</strong>
        <span>(MM/DD/YYYY) into the </span><code>Author:</code>
        <span>and </span><code>Date:</code>
        <span> fields of each file.</span>
    </div>
    <div class="step-block-header" role="heading" aria-level="2">
        <span>
            <br />Open the <em>code10-1.html</em> file and within the <code>head</code> section insert a <code>script</code> element connecting the page to the <em>gallery10-1.js</em> file. Add the <code>defer</code> attribute to the <code>script</code> element to defer the loading of the script until after the contents of the page loads.
        </span>
    </div>
    <div class="step-block-header" role="heading" aria-level="2">
        <span>
            <br />Open the <em>gallery10-1.js</em> file and below the code that creates and populates the captions array, declare the <code>htmlCode</code> variable, setting its initial value to an empty text string.
        </span>
    </div>
    <div class="step-block-header" role="heading" aria-level="2">
        <span>
            <span>
                <br />
            </span>
        </span>
        <p>Create a <code>for</code> loop with a counter variable <code>i</code> that goes from <strong>0</strong> to <strong>13</strong> in increments of <strong>1</strong>. Each time through the <code>for</code> loop, add the following code to the value of the <code>htmlCode</code> variable:</p>
        <pre class="cmh-pre light"><code class="cmh" data-language="html"><span><span class="mtk1">&lt;</span><span class="mtk15">figure</span><span class="mtk1">&gt;</span></span><br /><span><span class="mtk1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&lt;</span><span class="mtk15">img</span><span class="mtk1">&nbsp;</span><span class="mtk15">alt</span><span class="mtk1">=</span><span class="mtk29">'&nbsp;'</span><span class="mtk1">&nbsp;</span><span class="mtk15">src</span><span class="mtk1">=</span><span class="mtk29">'slidei.jpg'</span><span class="mtk1">&nbsp;/&gt;</span></span><br /><span><span class="mtk1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&lt;</span><span class="mtk15">figcaption</span><span class="mtk1">&gt;caption_i&lt;/</span><span class="mtk15">figcaption</span><span class="mtk1">&gt;</span></span><br /><span><span class="mtk1">&lt;/</span><span class="mtk15">figure</span><span class="mtk1">&gt;</span></span><br /></code></pre>
        <p>where <code>i</code> is the value of the counter variable and <em>caption_i</em> is the value from the captions array with index number <code>i</code>.</p>
        <p>After the <code>for</code> loop, change the inner HTML of the document element by the ID <strong>gallery</strong> to the value of the <code>htmlCode</code> variable.</p>
        <p>
            <span>Open the website in the browser preview. Verify that the page displays the 14 images in the slide gallery.</span>
        </p>
    </div>
</div>
