# t8-review
<div class="custom-markdown steps-contents">
    <h2>Summary</h2>
    <p>Maxine has been working on new pages at the Cinema Penguin website. She has returned for help on a page featuring a profile of Fred Astaire. Maxine created a sound clip from one of Astaire&rsquo;s songs in the Royal Wedding and a video clip of a dance in that movie featuring Astaire&rsquo;s duet with a hat rack. She wants both clips embedded on the page. In addition, Maxine wants you to try a new hover transition for the links at the top of the page. Finally, she wants you to create an animation that displays a scrolling marquee of the Fred Astaire filmography. <strong>Figure 8&ndash;63</strong> shows a preview of the final page.</p>
    <p>&nbsp;</p>
    <figure>
        <a class="markdown-image-link" title="Open image in a new tab" href="https://cdn.filestackcontent.com/u5ecj4sSpqG5JcTusVCx" target="_blank" rel="noopener">
            <img src="https://cdn.filestackcontent.com/u5ecj4sSpqG5JcTusVCx" alt="A homepage preview of Fred Astaire biography page. " />
        </a>
    </figure>
    <p>&nbsp;</p>
    <p><sup><em>Figure 8-63</em></sup></p>
    <h2>Document Setup</h2>
    <p>Open the <em>cp_astaire.html</em>, <em>cp_media2.css</em>, and <em>cp_animate2.css</em> files and enter your <strong>name</strong> and the <strong>date</strong> in the comment section of each file. Go to the <em>cp_astaire.html</em> file and insert links to the <em>cp_media2.css</em> and <em>cp_animate2.css</em> files. Take some time to study the contents and structure of the document.</p>
    <h2>Insert the Audio Clip</h2>
    <p>Scroll down to the <code>aside</code> element titled &ldquo;Listen up&rdquo;. Directly after the introductory paragraph, insert an audio clip with the audio controls displayed in the browser. Add two possible source files to the audio clip: <em>cp_song.mp3</em> and <em>cp_song.ogg</em>. Identify the <strong>mime-type</strong> of each audio source. In case a browser does not support HTML5 audio, display a paragraph with the message <strong>Upgrade your browser to HTML5</strong>.</p>
    <blockquote class="info">
        <p>The audio will not be audible using the browser preview in the lab environment.</p>
    </blockquote>
    <h2>Insert the Video Clip</h2>
    <p>Scroll down to the <code>aside</code> element titled &ldquo;In Focus&rdquo; and after the introductory paragraph insert a video clip with the video controls enabled and display the poster image <em>cp_poster.png</em>. Add two possible sources to the video clip: <em>cp_hatrack.mp4</em>and <em>cp_hatrack.webm</em>. Include the <strong>mime-type</strong> for each video source. If the user&rsquo;s browser does not support HTML5 video, display a paragraph with the message <strong>Upgrade your browser to HTML5</strong>.</p>
    <p>Directly after the two video sources in the <code>video</code> element you created in the last step, insert a caption track using the captions you will specify in the <em>cp_captions2.vtt</em> file in later steps. Set the value of the <code>kind</code> attribute to <strong>captions&nbsp;</strong>and give the caption track the <code>label</code> <strong>Movie Captions</strong> and set it as the default track for the video clip.</p>
    <h2>Add Track Cues</h2>
    <p>Open the <em>cp_captions2.vtt</em> file and add an initial line to the text file indicating that this file is in WEBVTT format. Next, add the following track cues to the <em>cp_caption2.vtt</em>file:</p>
    <ol>
        <li>A <strong>Title</strong> cue appearing in the <strong>0.5</strong>seconds to <strong>5</strong> second interval containing the text <strong>The Hat Rack Dance</strong> enclosed in a class tag with the name <code>Title</code>. Set the <code>line</code> and <code>align</code> attributes for the caption to <strong>10%</strong> and <strong>middle</strong>respectively to place the caption centered and near the top of the video window.</li>
        <li>A <strong>Subtitle</strong> cue in the <strong>5.5</strong> to <strong>9</strong> second interval with the text from <strong>Royal Wedding (1951)</strong>. Enclose &ldquo;Royal Wedding (1951)&rdquo; within <code>&lt;i&gt;</code> tags to italicize it. Place the caption at the <strong>10%</strong> <code>line</code> and <code>align</code> the caption text in the <strong>middle</strong>.</li>
        <li>A <strong>Finish</strong> cue displayed from the <strong>65</strong>second mark (1 minute and 5 seconds) to the <strong>71</strong> second mark (1 minute and 11 seconds) and containing the text <strong>See more videos at Cinema Penguin</strong>. Enclose &ldquo;Cinema Penguin&rdquo; within <code>&lt;i&gt;</code>tags and place the caption at the <strong>80%</strong> <code>line</code> and <strong>90%</strong> position with the caption text aligned at the <strong>end</strong>.</li>
    </ol>
    <h2>Track Styles</h2>
    <p>Next, open the <em>cp_media2.css</em> file and within the "Media Styles" section, insert a style rule for all <code>audio</code> and <code>video</code>elements that displays them as blocks with a <code>width</code> of <strong>95%</strong>. Center the <code>audio</code> and <code>video</code> elements by setting the top/bottom margins to <strong>20</strong> pixels and left/right margins set to <strong>auto</strong>. Go to the "Track Styles" section and create a style rule for track cues that:</p>
    <ol>
        <li>sets the background color to <strong>transparent</strong>,</li>
        <li>adds a <strong>black</strong> text shadow with horizontal and vertical offsets of <strong>1</strong> pixel and a blur of <strong>2</strong> pixels,</li>
        <li>sets the text color to <strong>rgb(255, 177, 66)</strong>, and</li>
        <li>sets the font size to <strong>1.2em</strong> using the <strong>sans serif</strong> font family.</li>
    </ol>
    <p>Create a style rule for track cues belonging to the <code>Title</code> class that sets the font size to <strong>2em</strong> and font family to <strong>serif</strong>.</p>
    <p>Open the <em>cp_astaire.html</em> file in the browser preview. Verify that you can play the audio and video clips and the layout matches that shown in <em>Figure 8&ndash;63</em>. Verify that captions are added to the video clip providing the title and subtitle of the clip at the start of the video and a message about Cinema Penguin at the end.</p>
    <h2>Transition Styles</h2>
    <p>Maxine wants to create a transition for the links at the top of the page that enlarges the link text and moves it out and above its default position. Return to the <em>cp_animate2.css</em> file and go to the "Transition Styles" section and create a style rule for the <code>nav#topLinks</code> a selector that:</p>
    <ol>
        <li>sets the text color to <strong>rgb(255, 255, 255)</strong>,</li>
        <li>adds a text shadow with the color <strong>rgba(0, 0, 0, 1)</strong>, a horizontal offset of <strong>1</strong>pixel, a vertical offset of <strong>&ndash;1</strong> pixel, and a blur of <strong>1</strong> pixel, and</li>
        <li>
            <p>uses the transform style to apply the functions <strong>scale(1,1)</strong> and <strong>translateY(0px)</strong>.</p>
            <p>Within the style rule you created above, add a transition that applies to all of the properties of the selected element over an interval of <strong>1.2</strong> seconds using linear timing.</p>
        </li>
    </ol>
    <p>Create a style rule for the <code>nav#topLinks a:hover</code> selector that:</p>
    <ol>
        <li>sets the text color to <strong>rgb(255, 183, 25)</strong>,</li>
        <li>sets the text shadow to the color <strong>rgba(0, 0, 0, 0.5)</strong> with a horizontal offset of <strong>0</strong> pixels, a vertical offset of <strong>15</strong>pixels, and a blur of <strong>4</strong> pixels, and</li>
        <li>
            <p>uses the transform style with <strong>scale(2,2)</strong>and <strong>translateY(-15px)</strong> to double the scale of the object and translate it <strong>&ndash;15</strong>pixels in the vertical direction.</p>
            <p>Reload <em>cp_astaire.html</em> in the browser preview. Hover your mouse pointer over the links at the top of the page and verify that your browser applies a transition over a <strong>1.2</strong> second duration as each link increases in size and appears to move upward and outward from the page in response to the hover event.</p>
        </li>
    </ol>
    <p>The list of Fred Astaire&rsquo;s films has been stored within a table nested within a <code>div</code>element with the ID <code>Marquee</code>. The table is long and Maxine wants to only display a portion of it at a time, allowing the contents of the table to automatically scroll upward as in a theater marquee. To create this animated effect, you change the top position style of the table over a specified time interval, moving the table upward through the marquee.</p>
    <h2>Marquee Styles</h2>
    <p>Return to the <em>cp_animate2.css</em> file and go to the "Marquee Styles" section and insert a style rule that places the marquee <code>div</code>element with relative positioning. Add a style rule for the <code>table</code> nested within the marquee <code>div</code> element that places the <code>table</code> using absolute positioning. Do not specify any coordinates for either element.</p>
    <h2>Keyframe Styles</h2>
    <p>Go to the "Keyframe Styles" section and create an animation named scroll with the following two key frames:</p>
    <ol>
        <li>at <strong>0%</strong>, set the value of the top property to <strong>250px</strong> and,</li>
        <li>at <strong>100%</strong>, set the value of the top property to <strong>&ndash;1300px</strong>.</li>
    </ol>
    <h2>Animation Styles</h2>
    <p>Go to the "Animation Styles" section and apply the scroll animation to the table within the marquee <code>div</code> element over a duration of <strong>50</strong> seconds using linear timing within infinite looping. Maxine wants the marquee to stop scrolling whenever the user hovers the mouse pointer over it. Add a style rule for the <code>div#marquee:hover table</code> selector that pauses the animation during the hover event.</p>
    <p>Reload the <em>cp_astaire.html</em> file in the browser preview. Verify that the marquee listing the Fred Astaire films starts scrolling automatically when the page loads, goes back to the beginning after the last film is listed, and stops whenever the user hovers the mouse pointer over the marquee.</p>
    <blockquote class="info">
        <p>On touchscreen devices, tap the marquee to initiate the hover event and pause the scrolling text, and then tap elsewhere on the page to remove the hover and restart the marquee.</p>
    </blockquote>
