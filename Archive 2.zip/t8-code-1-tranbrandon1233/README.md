# t8-code-1
<div class="custom-markdown steps-contents">
    <div class="step-block-outer step-block--not-last">
        <div class="step-block-header" role="heading" aria-level="2">
            <div class="step-block-outer step-block--not-last">
                <div class="step-block-header" role="heading" aria-level="2">
                    <div class="step-block-outer step-block--not-last">
                        <div class="step-block-header" role="heading" aria-level="2">
                            <div class="custom-markdown steps-contents">
                                <h2>Summary</h2>
                                <p>You are working on a skateboard website that provides instruction in various skateboarding techniques. In this coding challenge you will complete a web page detailing how to perform a trick known as a High Ollie in which the skateboarder jumps over high obstacles. You will augment the page with a video of the trick being performed. See <em>Figure 8&ndash;59</em>.</p>
                                <p>&nbsp;</p>
                                <figure>
                                    <a class="markdown-image-link" title="Open image in a new tab" href="https://cdn.filestackcontent.com/3HpuChMzQWOZgmw3nFOQ" target="_blank" rel="noopener">
                                        <img src="https://cdn.filestackcontent.com/3HpuChMzQWOZgmw3nFOQ" alt="A web page titled learning the high Ollie. The page consists of the detailed instruction on how to perform the nigh Ollie and a video illustration. In the video, a skateboarder jumps over high obstacles and demonstrates on how the high Ollie is performed. " />
                                    </a>
                                </figure>
                                <sup><em>Figure 8-59</em></sup>
                                <p>&nbsp;</p>
                                <p>Do the following:</p>
                            </div>
                            <div class="step-block-outer step-block--not-last">
                                <div class="step-block-header" role="heading" aria-level="2">Tasks</div>
                                <div class="step-block-header" role="heading" aria-level="2">
                                    <br />
                                    <span>Open the files </span><em>code8-1.html</em>
                                    <span> and </span><em>code8-1_video.css</em>
                                    <span> and in the comment section enter your </span><strong>name</strong>
                                    <span> (First + Last) and the </span><strong>date</strong>
                                    <span>(MM/DD/YYYY) into the </span><code>Author:</code>
                                    <span>and </span><code>Date:</code>
                                    <span> fields of each file.</span>
                                </div>
                                <div class="step-block-header" role="heading" aria-level="2">
                                    <br />
                                    <span>Go to the </span><em>code8-1.html</em>
                                    <span> file and within the </span><code>head</code>
                                    <span> section insert a </span><code>link</code>
                                    <span> element linking the page to the </span><em>code8-1_video.css</em>
                                    <span> style sheet file.</span>
                                </div>
                                <div class="step-block-header" role="heading" aria-level="2">
                                    <br />
                                    <p>Below the ordered list insert a <code>video</code> element with the following features:</p>
                                    <ol>
                                        <li>Add the controls attribute to the <code>video</code> element to show player controls.</li>
                                        <li>Add the source files <em>ollie.mp4</em>and <em>ollie.webm</em> to the video element. Include the <code>mime-type</code> for both video files.</li>
                                        <li>If a browser doesn&rsquo;t support HTML video, display a paragraph containing the text <strong>Upgrade your browser to view embedded videos</strong>.</li>
                                        <li>Add a track using the contents of the <em>captions8-1.vtt</em> file. Set the value of the <code>kind</code> attribute to captions and add the label <strong>Video Captions</strong>.</li>
                                    </ol>
                                    <p>Go to the <em>code8-1_video.css</em> file and add a style rule for the <code>video</code> element that:</p>
                                    <ol>
                                        <li>Displays the video player as a block element,</li>
                                        <li>Sets the <code>width</code> of the player to <strong>75%</strong>, and</li>
                                        <li>Sets the top/bottom margin to <strong>10</strong> pixels and the left/right margins to <strong>auto</strong>.</li>
                                    </ol>
                                    <p>
                                        <span>Open the </span><em>captions8-1.vtt</em>
                                        <span> file in your editor and create a cue with the </span><code>label</code> <strong>Caption</strong>
                                        <span> going from </span><strong>3</strong>
                                        <span>to </span><strong>6</strong>
                                        <span> seconds of the video and displaying the text </span><strong>A High Ollie&nbsp;</strong>
                                        <span>during that interval. Link the </span><em>captions8-1.vtt</em>
                                        <span> file to the video using the </span><code>track</code>
                                        <span> element.</span>
                                    </p>
                                    <p>
                                        <span>Test your page in the browser preview, verifying that you can play the video clip of the High Ollie and that a caption appears from 3 to 6 seconds of the video.</span>
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="step-block-header" role="heading" aria-level="2">
                            <span>&nbsp;</span>
                        </div>
                    </div>
                </div>
            </div>
