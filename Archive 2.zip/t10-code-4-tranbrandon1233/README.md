<div class="custom-markdown steps-contents">
    <h2>Summary</h2>
    <p><strong>Figure 10&ndash;37</strong> shows a page that contains monthly calendars for every month of the year. You&rsquo;ve been given the files for this page but there are several errors that prevent the code from running correctly. You will analyze the code and correct the mistakes.</p>
    <p>&nbsp;</p>
    <figure>
        <a class="markdown-image-link" title="Open image in a new tab" href="https://cdn.filestackcontent.com/AXA7fSxbTiOeyf2qLW0l" target="_blank" rel="noopener">
            <img src="https://cdn.filestackcontent.com/AXA7fSxbTiOeyf2qLW0l" alt="A page depicts the annual calendar of 2021 is displayed." />
        </a>
    </figure>
    <sup><em>Figure 10-37</em></sup>
    <p>&nbsp;</p>
    <p>Do the following:</p>
</div>
<div class="step-block-outer step-block--not-last">
    <div class="step-block-header" role="heading" aria-level="2">Tasks</div>
    <div class="step-block-header" role="heading" aria-level="2">
        <span>Open the files </span><em>code10-4.html</em>
        <span> and </span><em>debug10-4.js</em>
        <span> and in the comment section enter your </span><strong>name</strong> <strong>(First + Last)</strong>
        <span> and the </span><strong>date</strong>
        <span>(</span><strong>MM/DD/YYYY</strong>
        <span>) into the </span><code>Author:</code>
        <span>and </span><code>Date:</code>
        <span>fields of each file.</span>
    </div>
    <div class="step-block-header" role="heading" aria-level="2">
        <span>
            <br />Open the <em>code10-4.html</em> file and within the <code>head</code> section insert a <code>script</code> element connecting the page to the <em>debug10-4.js</em> file. Add the <code>defer</code> attribute to the <code>script</code> element.
        </span>
    </div>
    <div class="step-block-header" role="heading" aria-level="2">
        <span>
            <span>
                <br />
            </span>
        </span>
        <p>Open the <em>debug10-4.js</em> file and fix the syntax errors in the following locations to allow the code to run correctly (there are no logic errors in the code):</p>
        <ol>
            <li>Fix the statement that declares the <code>thisDay</code>variable.</li>
            <li>Fix the statement that declares the <code>monthName</code>variable.</li>
            <li>Fix the <code>for</code> loop that calls the <code>writeMonthTable()</code>function.</li>
            <li>Fix the code that writes the value of the <code>htmlCode</code>variable into the element with ID <strong>calendar</strong>.</li>
            <li>Fix the three <code>if</code> statements found within the <code>writeMonthTable()</code> function</li>
        </ol>
        <p>
            <span>Open the website in the browser preview. When the page is free of errors, you should see a calendar for the current year with the current day highlighted on the page.</span>
        </p>
    </div>
</div>
