# t9-code-1

## Summary
You are working on a JavaScript clock that will show the date, day of the week, and time. The clock will update every second. The clock will update every second. Figure 9–40 shows a preview of the completed page. 

![](clock1.gif)

Do the following:

## Tasks
Open the files*code9-1.html* and*clock9-1.js* and in the comment section enter your **name** (First + Last) and the **date** (MM/DD/YYYY) into the ```Author:``` and ```Date:``` fields of each file.

Open the*code9-1.html*file and within the ```head``` section insert a ```script``` element connecting the page to the*clock9-1.js*file. Add the ```defer``` attribute to the ```script``` element to defer the loading of the script until after the page contents load.

Open to the*clock9-1.js* file and directly below the initial comment section, insert the ```runClock()``` function. Within the function do the following:

1. Declare the ```thisDay``` variable containing the current date using the ```new Date()``` command.

2. Create the ```thisDate``` variable containing the text string of the current date by applying the ```toLocaleDateString()``` method to the ```thisDay``` variable.

3. Create the ```thisDayNum``` variable to store the number of the current weekday by applying the ```getDay()``` method to the ```thisDay``` variable.

4. Create the ```thisWeekday``` variable by storing the value returned by the ```getWeekday()``` function using ```thisDayNum``` as the function value.

4. Create the ```thisTime``` variable containing the text string of the current date by applying the ```toLocaleTimeString()``` method to the ```thisDay``` variable.

5. Using the ```textContent``` property, change the text stored in the document element with the ID **date** to the value of the ```thisDate```
variable, the text stored in the document with element with **wday**
ID to the value of the ```thisWeekday``` variable, and the text stored in the document element with the ID **time** to the value of the ```thisTime```
variable.

Directly before the ```runClock()``` function insert a statement to run the ```runClock()``` function and then another statement that uses the ```setInterval()``` method to run the ```runClock()``` function every second.
