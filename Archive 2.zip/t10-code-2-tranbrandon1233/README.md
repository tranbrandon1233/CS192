<div class="custom-markdown steps-contents">
    <h2>Summary</h2>
    <p>In this Coding Challenge you will use JavaScript to write the contents of a table listing the top ranked movies on the IMDb website. The names of the movies, descriptions, scores, and links to pages describing the movies have been stored in arrays. You will use a for loop to write the individual rows of the table. <em>Figure 10&ndash;35</em>shows a preview of the completed page.</p>
    <p>&nbsp;</p>
    <figure>
        <a class="markdown-image-link" title="Open image in a new tab" href="https://cdn.filestackcontent.com/8k3oUFjxSqy9DgOr7OF6" target="_blank" rel="noopener">
            <img src="https://cdn.filestackcontent.com/8k3oUFjxSqy9DgOr7OF6" alt="A page titled, I M D b top movie list displays the list of 10 movies with its description and score in the form of table. It has three columns and the column headers reads, movie, description and score.  " />
        </a>
    </figure>
    <sup><em>Figure 10-35</em></sup>
    <p>&nbsp;</p>
    <p>Do the following:</p>
</div>
<div class="step-block-outer step-block--not-last">
    <div class="step-block-header" role="heading" aria-level="2">Tasks</div>
    <div class="step-block-header" role="heading" aria-level="2">
        <span>Open the files </span><em>code10-2.html</em>
        <span> and </span><em>list10-2.js</em>
        <span> and in the comment section enter your </span><strong>name</strong>
        <span> (First + Last) and the </span><strong>date</strong>
        <span>(MM/DD/YYYY) into the </span><code>Author:</code>
        <span>and </span><code>Date:</code>
        <span> fields of each file.</span>
    </div>
    <div class="step-block-header" role="heading" aria-level="2">
        <span>
            <br />Open the <em>code10-2.html</em> file and within the <code>head</code> section insert a <code>script</code> element connecting the page to the <em>list10-2.js</em> file. Add the <code>defer</code> attribute to the <code>script</code> element.
        </span>
    </div>
    <div class="step-block-header" role="heading" aria-level="2">
        <span>
            <span>
                <br />
            </span>
        </span>
        <p>Open the <em>list10-2.js</em> file and directly below the code populating the links array, declare the <code>htmlCode</code> variable. Store within the variable the following text:</p>
        <pre class="cmh-pre light"><code class="cmh" data-language="html"><span><span class="mtk1">&lt;</span><span class="mtk15">table</span><span class="mtk1">&gt;</span></span><br /><span><span class="mtk1">&nbsp;&nbsp;&nbsp;&nbsp;&lt;</span><span class="mtk15">thead</span><span class="mtk1">&gt;</span></span><br /><span><span class="mtk1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&lt;</span><span class="mtk15">tr</span><span class="mtk1">&gt;&nbsp;</span></span><br /><span><span class="mtk1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&lt;</span><span class="mtk15">th</span><span class="mtk1">&gt;Movie&lt;/</span><span class="mtk15">th</span><span class="mtk1">&gt;&lt;</span><span class="mtk15">th</span><span class="mtk1">&gt;Description&lt;/</span><span class="mtk15">th</span><span class="mtk1">&gt;&lt;</span><span class="mtk15">th</span><span class="mtk1">&gt;Score&lt;/</span><span class="mtk15">th</span><span class="mtk1">&gt;</span></span><br /><span><span class="mtk1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&lt;/</span><span class="mtk15">tr</span><span class="mtk1">&gt;</span></span><br /><span><span class="mtk1">&nbsp;&nbsp;&nbsp;&nbsp;&lt;/</span><span class="mtk15">thead</span><span class="mtk1">&gt;</span></span><br /><span><span class="mtk1">&nbsp;&nbsp;&nbsp;&nbsp;&lt;</span><span class="mtk15">tbody</span><span class="mtk1">&gt;</span></span></code><br /><br /></pre>
        <p>Open the <em>list10-2.js</em> file and directly below your previous code create a <code>for</code> loop with a counter variable <code>i</code> that goes from <strong>0</strong> to <strong>9</strong>. Each time through the <code>for</code> loop add the following text to the <code>htmlCode</code> variable:</p>
        <pre class="cmh-pre light"><code class="cmh" data-language="html"><span><span class="mtk1">&lt;</span><span class="mtk15">tr</span><span class="mtk1">&gt;</span></span><br /><span><span class="mtk1">&nbsp;&nbsp;&nbsp;&nbsp;&lt;</span><span class="mtk15">td</span><span class="mtk1">&gt;&lt;</span><span class="mtk15">a</span><span class="mtk1">&nbsp;</span><span class="mtk15">href</span><span class="mtk1">=</span><span class="mtk29">'links_i'</span><span class="mtk1">&gt;titles_i&lt;/</span><span class="mtk15">a</span><span class="mtk1">&gt;&lt;</span><span class="mtk15">td</span><span class="mtk1">&gt;</span></span><br /><span><span class="mtk1">&nbsp;&nbsp;&nbsp;&nbsp;&lt;</span><span class="mtk15">td</span><span class="mtk1">&gt;summaries_i&lt;/</span><span class="mtk15">td</span><span class="mtk1">&gt;&nbsp;</span></span><br /><span><span class="mtk1">&nbsp;&nbsp;&nbsp;&nbsp;&lt;</span><span class="mtk15">td</span><span class="mtk1">&gt;ratings_i&lt;/</span><span class="mtk15">td</span><span class="mtk1">&gt;</span></span><br /><span><span class="mtk1">&lt;/</span><span class="mtk15">tr</span><span class="mtk1">&gt;</span></span><br /></code></pre>
        <p>where <code>i</code> is the value of the counter variable, and <strong>links_i</strong>, <strong>titles_i</strong>, <strong>summaries_i</strong>, and <strong>ratings_i</strong> are the values from the <code>links</code>, <code>titles</code>, <code>summaries</code>, and <code>ratings</code> array with index number <code>i</code>.</p>
        <p>After the <code>for</code> loop add the following text to the <code>htmlCode</code>variable:</p>
        <pre class="cmh-pre light"><code class="cmh" data-language="html"><span><span class="mtk1">&nbsp;&nbsp;&nbsp;&nbsp;&lt;/</span><span class="mtk15">tbody</span><span class="mtk1">&gt;</span></span><br /><span><span class="mtk1">&lt;/</span><span class="mtk15">table</span><span class="mtk1">&gt;</span></span><br /></code></pre>
        <p>Store the value of the <code>htmlCode</code>variable in the inner HTML of the element with the ID <strong>list</strong>.</p>
        <p>
            <span>Open the website in the browser preview. Verify that the page displays the table describing the ten movies from the IMDb movie list. Also verify that when you click the links in the Movie column you are redirected to a page providing information about the selected movie.</span>
        </p>
    </div>
</div>
