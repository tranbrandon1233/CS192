# t10-case-2
Voter Web
<h2>Summary</h2>
<p><strong>VoterWeb</strong> - Pam Carls is a manager for the website Voter Web, which compiles voting totals and statistics from local and national elections. Pam has the results of recent congressional elections from eight districts in Minnesota stored as multidimensional arrays in a JavaScript file. Pam wants you to create a script displaying these results and calculating the vote percentage for each candidate within each race. A preview of the page is shown in <strong>Figure 10&ndash;40</strong>.</p>
<p>&nbsp;</p>
<figure>
    <a class="markdown-image-link" title="Open image in a new tab" href="https://cdn.filestackcontent.com/WCFqMGPJSKOSQWhezNUZ" target="_blank" rel="noopener">
        <img style="display: block; margin-left: auto; margin-right: auto;" src="https://cdn.filestackcontent.com/WCFqMGPJSKOSQWhezNUZ" alt="A home page of Voter Web is displayed. Six tabs displayed below the heading, Voter Web are: U.S. Congress, U.S. Senate, State Governors, Presidential, Timeline, and Search. The left pane of the page displays the list of States in U.S. The Sub-heading, Minnesota Congressional Elections is displayed below the tabs at the right pane. Below the sub heading, the voting rate of eight districts is displayed. Each district has three candidates and the voting rates for each district are displayed using a bar graph. " />
    </a>
</figure>
<p style="text-align: center;">
    <br />&nbsp;<em></em><em>Figure 10&ndash;40</em>&nbsp;&nbsp;
</p>
<h2>Document Setup</h2>
<p>Open the <em>vw_election.html</em> and <em>vw_results.js</em> files and enter your <strong>name</strong>and the <strong>date</strong> in the comment section of each file. Next, go to the <em>vw_election.html</em>file and directly above the closing <code>&lt;/head&gt;</code>tag, insert <code>script</code> elements to link the page to the <em>vw_congminn.js</em> and <em>vw_results.js</em> files in that order. Defer the loading and running of both script files until after the page has loaded.</p>
<p>Scroll down the file and, directly above the <code>footer</code>, insert an empty <code>section</code>element. You will write the HTML code of the election report in this element.</p>
<p>Open the <em>vw_congminn.js</em> file and study the contents. Note that the file contains the results of 8 congressional elections in Minnesota. The candidate information is stored in multidimensional arrays named <code>candidate</code>, <code>party</code>, and <code>votes</code>. Do not make any changes to this file.</p>
<h2>Calculate the <code>totalVotes</code></h2>
<p>Next, go to the <em>vw_results.js</em> file and declare a variable named <code>reportHTML</code>containing the following HTML text: <code>&lt;h1&gt;title&lt;/h1&gt;</code> where <strong>title</strong> is the value of the <code>raceTitle</code> variable stored in the <em>vw_congminn.js</em> file</p>
<p>Create a <code>for</code> loop that loops through the contents of the <code>race</code> array using <code>i</code> as the counter variable. Place the commands specified in <em>steps 1</em> through <em>5</em> within this program for loop:</p>
<ol>
    <li>Create a variable named <code>totalVotes</code>that will store the total votes cast in each race. Set its initial value to <strong>0</strong>.</li>
    <li>Calculate the total votes cast in the current race by applying the <code>forEach()</code> method to <code>i</code>th index of the <code>votes</code> array using the <code>calcSum()</code>function as the callback function.</li>
    <li>Add the following HTML text to the value of the <code>reportHTML</code> variable to write the name of the current race in the program loop:
        <pre class="cmh-pre light"><code class="cmh" data-language="html"><span><span class="mtk1">&lt;</span><span class="mtk15">table</span><span class="mtk1">&gt;</span></span><br /><span><span class="mtk1">&lt;</span><span class="mtk15">caption</span><span class="mtk1">&gt;race&lt;/</span><span class="mtk15">caption</span><span class="mtk1">&gt;</span></span><br /><span><span class="mtk1">&lt;</span><span class="mtk15">tr</span><span class="mtk1">&gt;&lt;</span><span class="mtk15">th</span><span class="mtk1">&gt;Candidate&lt;/</span><span class="mtk15">th</span><span class="mtk1">&gt;&lt;</span><span class="mtk15">th</span><span class="mtk1">&gt;Votes&lt;/</span><span class="mtk15">th</span><span class="mtk1">&gt;&lt;/</span><span class="mtk15">tr</span><span class="mtk1">&gt;</span></span><br /></code></pre>
        where <strong>race</strong> is the <code>i</code>th index of the <code>race</code> array.
    </li>
    <li>Call the <code>candidateRows()</code> function (you will create this function shortly) using the counter variable <code>i</code> and the <code>totalVotes</code> variable as parameter values. Add the value returned by this function to the value of the <code>reportHTML</code> variable.</li>
    <li>Add the text <code>&lt;/table&gt;</code> to the value of the <code>reportHTML</code> variable.</li>
</ol>
<p>After the <code>for</code> loop has completed, write the value of the <code>reportHTML</code> variable into the innerHTML of the first (and only) <code>section</code> element in the document.</p>
<h2>Create the <code>candidateRows()</code>function</h2>
<p>Next, create the <code>candidateRows()</code>function. The purpose of this function is to write individual table rows for each candidate, showing the candidate&rsquo;s name, party affiliation, vote total,and vote percentage. The <code>candidateRows()</code>function has two parameters named <code>raceNum</code> and <code>totalVotes</code>. Place the commands in <em>steps 1</em> through <em>3</em> within this function:</p>
<ol>
    <li>Declare a local variable named <code>rowHTML</code> that will contain the HTML code for the table row. Set the initial value of this variable to an empty text string.</li>
    <li>
        <p>Create a <code>for</code> loop in which the counter variable <code>j</code> goes from <strong>0</strong> to <strong>2</strong> in steps of <strong>1</strong> unit. Within the <code>for</code> loop do the following:</p>
        <ul>
            <li>
                <p>Declare a variable named <code>candidateName</code> that retrieves the name of the current candidate and the current race.</p>
                <blockquote class="info">
                    <p>Retrieve the candidate name from the multidimensional candidate array using the reference, <code>candidate[raceNum][j]</code>.</p>
                </blockquote>
            </li>
            <li>
                <p>Declare a variable named <code>candidateParty</code> that retrieves the party affiliation of the current candidate in the current race from the multidimensional party array.</p>
            </li>
            <li>Declare a variable named <code>candidateVotes</code> that retrieves the votes cast for the current candidate in the current race from the multidimensional votes array.</li>
            <li>Declare a variable named <code>candidatePercent</code> equal to the value returned by the <code>calcPercent()</code> function, calculating the percentage of votes received by the current candidate in the loop. Use <code>candidateVotes</code>as the first parameter value and <code>totalVotes</code> as the second parameter value.</li>
            <li>Add the following HTML code to the value of the rowHTML variable:
                <pre class="cmh-pre light"><code class="cmh" data-language="html"><span><span class="mtk1">&lt;</span><span class="mtk15">tr</span><span class="mtk1">&gt;</span></span><br /><span><span class="mtk1">&nbsp;&nbsp;&lt;</span><span class="mtk15">td</span><span class="mtk1">&gt;name&nbsp;(party)&lt;/</span><span class="mtk15">td</span><span class="mtk1">&gt;</span></span><br /><span><span class="mtk1">&nbsp;&nbsp;&lt;</span><span class="mtk15">td</span><span class="mtk1">&gt;votes&nbsp;(percent)&lt;/</span><span class="mtk15">td</span><span class="mtk1">&gt;</span></span><br /><span><span class="mtk1">&lt;/</span><span class="mtk15">tr</span><span class="mtk1">&gt;</span></span><br /></code></pre>
                where <strong>name</strong> is the value of <code>candidateName</code>, <strong>party</strong> is the value of <code>candidateParty</code>, <strong>votes</strong> is the value of <code>candidateVotes</code>, and <strong>percent</strong> is the value of <code>candidatePercent</code>. Apply the <code>toLocaleString()</code> method to <code>votes</code> in order to display the vote total with a thousands separator. Apply the <code>toFixed(1)</code> method to <code>percent</code> in order to display percentage values to <strong>1</strong> decimal place.
            </li>
        </ul>
    </li>
    <li>Return the value of the <code>rowHTML</code>variable.</li>
</ol>
<p>Open the website in the browser preview. Verify that the three candidate names, party affiliations, votes, and vote percentages are shown for each of the eight congressional races.</p>
<h2>Use Bar Charts to Display the Voting Data</h2>
<p>Pam also wants the report to display the vote percentages as bar charts with the length of the bar corresponding to the percentage value. Return to the <em>vw_results.js</em> file and at the bottom of the file, create a function named <code>createBar()</code>with one parameter named <code>partyType</code>. Add the commands described in <em>steps 1</em>through <em>2</em> to the function:</p>
<ol>
    <li>Declare a variable named <code>barHTML</code>and set its initial value to an empty text string.</li>
    <li>Create a switch/case statement that tests the value of the <code>partyType</code>parameter. If <code>partyType</code> equal <strong>D</strong> set <code>barHTML</code> equal to:
        <pre class="cmh-pre light"><code class="cmh" data-language="html"><span><span class="mtk1">&lt;</span><span class="mtk15">td</span><span class="mtk1">&nbsp;</span><span class="mtk15">class</span><span class="mtk1">=</span><span class="mtk29">'dem'</span><span class="mtk1">&gt;&lt;/</span><span class="mtk15">td</span><span class="mtk1">&gt;</span></span><br /></code></pre>
        If <strong>partyType</strong> equals <strong>R</strong> set <code>barHTML</code>equal to:
        <pre class="cmh-pre light"><code class="cmh" data-language="html"><span><span class="mtk1">&lt;</span><span class="mtk15">td</span><span class="mtk1">&nbsp;</span><span class="mtk15">class</span><span class="mtk1">=</span><span class="mtk29">'rep'</span><span class="mtk1">&gt;&lt;/</span><span class="mtk15">td</span><span class="mtk1">&gt;</span></span><br /></code></pre>
        Finally, if <code>partyType</code> equals <strong>I</strong> set barHTML to:
        <pre class="cmh-pre light"><code class="cmh" data-language="html"><span><span class="mtk1">&lt;</span><span class="mtk15">td</span><span class="mtk1">&nbsp;</span><span class="mtk15">class</span><span class="mtk1">=</span><span class="mtk29">'ind'</span><span class="mtk1">&gt;&lt;/</span><span class="mtk15">td</span><span class="mtk1">&gt;</span></span><br /></code></pre>
    </li>
</ol>
<p>Return the value of <code>barHTML</code>. Next, add these empty data cells to the race results table, with one cell for every percentage point cast for the candidate.</p>
<p>Scroll up to the <code>candidateRows()</code>function. Directly before the line that adds the HTML code <code>&lt;/tr&gt;</code> to the value of the <code>rowHTML</code> variable, insert a <code>for</code> loop with a counter variable <code>k</code> that goes from <strong>0</strong> up to a value less than <code>candidatePercent</code> in increments of <strong>1</strong> unit. Each time through the loop call the <code>createBar()</code> function using <code>candidateParty</code> and <code>candidatePercent</code> as the parameter values.</p>
<p>Add comments throughout the file with descriptive information about the variables and functions. Reload <em>vw_election.html</em> in your browser. Verify that each election table shows a bar chart with different the length of bars representing each candidate&rsquo;s vote percentage.</p>
