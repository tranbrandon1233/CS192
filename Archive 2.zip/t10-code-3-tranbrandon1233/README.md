<div class="custom-markdown steps-contents">
    <h2>Summary</h2>
    <p>You can use the switch/case statement to apply different possible values to the same variable. <em>Figure 10&ndash;36</em> shows a web page that displays different banner image on each day of the week. You will write the code to generate this page.</p>
    <p>&nbsp;</p>
    <figure>
        <a class="markdown-image-link" title="Open image in a new tab" href="https://cdn.filestackcontent.com/otpTDayQcOYhqNRybkn6" target="_blank" rel="noopener">
            <img src="https://cdn.filestackcontent.com/otpTDayQcOYhqNRybkn6" alt="A cartoon titled, &ldquo;Day of the Week&rdquo; depicts a penguin knitting a cloth. The text above the penguin reads, Tired Thursday." />
        </a>
    </figure>
    <sup><em>Figure 10-36</em></sup>
    <p>&nbsp;</p>
    <p>Do the following:</p>
</div>
<div class="step-block-outer step-block--not-last">
    <div class="step-block-header" role="heading" aria-level="2">Tasks</div>
    <div class="step-block-header" role="heading" aria-level="2">
        <span>Open the files </span><em>code10-3.html</em>
        <span> and </span><em>days10-3.js</em>
        <span> and in the comment section enter your </span><strong>name</strong>
        <span> (First + Last) and the </span><strong>date</strong>
        <span>(MM/DD/YYYY) into the </span><code>Author:</code>
        <span>and </span><code>Date:</code>
        <span> fields of each file.</span>
    </div>
    <div class="step-block-header" role="heading" aria-level="2">
        <span>
            <br />Open the <em>code10-3.html</em> file and within the <code>head</code> section insert a <code>script</code> element connecting the page to the <em>days10-3.js</em> file. Add the <code>defer</code> attribute to the <code>script</code> element.
        </span>
    </div>
    <div class="step-block-header" role="heading" aria-level="2">
        <span>
            <br />Next, open the <em>days10-3.js</em> file and below the initial comment section, create a variable named <code>thisDay</code> containing the date object for the current date.
        </span>
    </div>
    <div class="step-block-header" role="heading" aria-level="2">
        <span>
            <br />Use the <code>getDay()</code> method to extract the day of the week from the <code>thisDay</code> variable, storing the value in the <code>wDay</code> variable
        </span>
    </div>
    <div class="step-block-header" role="heading" aria-level="2">
        <br />
        <span>Declare a variable named </span><code>imgSrc</code>
        <span> setting its initial value to an empty text string.</span>
    </div>
    <div class="step-block-header" role="heading" aria-level="2">
        <span style="color: var(--ic-brand-font-color-dark); font-family: inherit; font-size: 1rem;">
            <br />Create a switch/case statement that tests values of the
        </span><code style="color: var(--ic-brand-font-color-dark);">wDay</code>
        <span style="color: var(--ic-brand-font-color-dark); font-family: inherit; font-size: 1rem;">variable from </span><strong style="color: var(--ic-brand-font-color-dark); font-family: inherit; font-size: 1rem;">0</strong>
        <span style="color: var(--ic-brand-font-color-dark); font-family: inherit; font-size: 1rem;"> to </span><strong style="color: var(--ic-brand-font-color-dark); font-family: inherit; font-size: 1rem;">6</strong>
        <span style="color: var(--ic-brand-font-color-dark); font-family: inherit; font-size: 1rem;">. If </span><code style="color: var(--ic-brand-font-color-dark);">wDay</code>
        <span style="color: var(--ic-brand-font-color-dark); font-family: inherit; font-size: 1rem;">equals </span><strong style="color: var(--ic-brand-font-color-dark); font-family: inherit; font-size: 1rem;">0</strong>
        <span style="color: var(--ic-brand-font-color-dark); font-family: inherit; font-size: 1rem;">, set </span><code style="color: var(--ic-brand-font-color-dark);">imgSrc</code>
        <span style="color: var(--ic-brand-font-color-dark); font-family: inherit; font-size: 1rem;"> to the text string </span><strong style="color: var(--ic-brand-font-color-dark); font-family: inherit; font-size: 1rem;">sunday.png</strong>
        <span style="color: var(--ic-brand-font-color-dark); font-family: inherit; font-size: 1rem;">; if </span><code style="color: var(--ic-brand-font-color-dark);">wDay</code>
        <span style="color: var(--ic-brand-font-color-dark); font-family: inherit; font-size: 1rem;">equals </span><strong style="color: var(--ic-brand-font-color-dark); font-family: inherit; font-size: 1rem;">1</strong>
        <span style="color: var(--ic-brand-font-color-dark); font-family: inherit; font-size: 1rem;">, set</span><code style="color: var(--ic-brand-font-color-dark);">imgSrc</code>
        <span style="color: var(--ic-brand-font-color-dark); font-family: inherit; font-size: 1rem;"> to </span><strong style="color: var(--ic-brand-font-color-dark); font-family: inherit; font-size: 1rem;">monday.png</strong>
        <span style="color: var(--ic-brand-font-color-dark); font-family: inherit; font-size: 1rem;">; and so forth.</span>
        <br />
        <p>Store the text string <code>&lt;img src='imgsrc' alt='' /&gt;</code>in the <code>htmlCode</code> variable where <code>imgsrc</code> is the value of the <code>imgSrc</code> variable.</p>
        <p>Store the value of the <code>imgSrc</code>variable in the inner HTML of the element with the ID <strong>banner</strong>.</p>
        <p>
            <span>Open the website in the browser preview and verify that the page shows the banner image for the current day.</span>
        </p>
    </div>
</div>
